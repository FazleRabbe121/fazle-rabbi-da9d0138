"""SQLite storage = the agent's memory. Also holds the send queue (outbox)."""
from __future__ import annotations

import sqlite3
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

FMT = "%Y-%m-%dT%H:%M:%SZ"

SCHEMA = """
CREATE TABLE IF NOT EXISTS companies (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT, website TEXT, domain TEXT UNIQUE,
  country TEXT, city TEXT, address TEXT, phone TEXT, source TEXT, osm_email TEXT,
  status TEXT DEFAULT 'new',
  score INTEGER DEFAULT 0, score_reasons TEXT DEFAULT '',
  has_job INTEGER DEFAULT 0, visa_signal TEXT DEFAULT '', accommodation INTEGER DEFAULT 0,
  roles TEXT DEFAULT '', summary TEXT DEFAULT '', career_url TEXT DEFAULT '',
  apply_url TEXT DEFAULT '', best_email TEXT DEFAULT '', language TEXT DEFAULT '',
  red_flags TEXT DEFAULT '', created_at TEXT, analyzed_at TEXT
);
CREATE INDEX IF NOT EXISTS ix_companies_status ON companies(status);

CREATE TABLE IF NOT EXISTS emails (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL, email TEXT NOT NULL,
  kind TEXT DEFAULT 'general', source TEXT DEFAULT '',
  UNIQUE(company_id, email)
);

CREATE TABLE IF NOT EXISTS outbox (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER, to_email TEXT NOT NULL, subject TEXT, body TEXT, lang TEXT,
  kind TEXT DEFAULT 'initial', parent_id INTEGER,
  status TEXT DEFAULT 'draft',  -- draft|approved|sending|sent|failed|needs_review|skipped
  message_id TEXT, attempts INTEGER DEFAULT 0, last_error TEXT DEFAULT '',
  next_try_at TEXT, created_at TEXT, approved_at TEXT, sent_at TEXT,
  replied_at TEXT, reply_snippet TEXT DEFAULT '', bounced INTEGER DEFAULT 0
);
-- Only ONE live initial application per address, ever: the database itself blocks duplicates.
CREATE UNIQUE INDEX IF NOT EXISTS ux_outbox_initial
  ON outbox(to_email) WHERE kind='initial' AND status NOT IN ('skipped','failed');
CREATE INDEX IF NOT EXISTS ix_outbox_status ON outbox(status);

CREATE TABLE IF NOT EXISTS suppression (
  email TEXT PRIMARY KEY, reason TEXT, created_at TEXT
);
CREATE TABLE IF NOT EXISTS searches (
  id INTEGER PRIMARY KEY AUTOINCREMENT, city TEXT, country TEXT, kinds TEXT DEFAULT 'hotels',
  status TEXT DEFAULT 'new', note TEXT DEFAULT '', created_at TEXT
);
CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT);
"""

OUTBOX_FIELDS = {
    "status", "message_id", "attempts", "last_error", "next_try_at", "approved_at",
    "sent_at", "replied_at", "reply_snippet", "bounced", "subject", "body",
}
COMPANY_FIELDS = {
    "status", "score", "score_reasons", "has_job", "visa_signal", "accommodation", "roles",
    "summary", "career_url", "apply_url", "best_email", "language", "red_flags", "analyzed_at",
}


def utcnow() -> str:
    return datetime.now(timezone.utc).strftime(FMT)


def utc_in(**delta) -> str:
    return (datetime.now(timezone.utc) + timedelta(**delta)).strftime(FMT)


class DB:
    def __init__(self, path: str = "data/jobhunter.db"):
        if path != ":memory:":
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self.conn.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA busy_timeout=5000")
        self.conn.executescript(SCHEMA)

    # ---- generic helpers -------------------------------------------------
    def q(self, sql: str, params=()):
        with self.lock:
            return self.conn.execute(sql, params).fetchall()

    def one(self, sql: str, params=()):
        with self.lock:
            return self.conn.execute(sql, params).fetchone()

    def x(self, sql: str, params=()):
        with self.lock:
            return self.conn.execute(sql, params)

    def kv_get(self, k: str, default: str = "") -> str:
        r = self.one("SELECT v FROM kv WHERE k=?", (k,))
        return r["v"] if r else default

    def kv_set(self, k: str, v: str) -> None:
        self.x("INSERT INTO kv(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", (k, v))

    # ---- companies ---------------------------------------------------------
    def add_company(self, name, website, domain, country, city, address="", phone="",
                    source="", osm_email="") -> int | None:
        cur = self.x(
            "INSERT OR IGNORE INTO companies(name,website,domain,country,city,address,phone,"
            "source,osm_email,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
            (name, website, domain, country, city, address, phone, source, osm_email, utcnow()),
        )
        return cur.lastrowid if cur.rowcount else None

    def get_company(self, cid: int):
        return self.one("SELECT * FROM companies WHERE id=?", (cid,))

    def set_company(self, cid: int, **f) -> None:
        f = {k: v for k, v in f.items() if k in COMPANY_FIELDS}
        if not f:
            return
        cols = ", ".join(f"{k}=?" for k in f)
        self.x(f"UPDATE companies SET {cols} WHERE id=?", (*f.values(), cid))

    def claim_new_companies(self, n: int) -> list[int]:
        with self.lock:
            self.conn.execute("BEGIN IMMEDIATE")
            try:
                rows = self.conn.execute(
                    "SELECT id FROM companies WHERE status='new' ORDER BY id LIMIT ?", (n,)
                ).fetchall()
                ids = [r["id"] for r in rows]
                for i in ids:
                    self.conn.execute("UPDATE companies SET status='crawling' WHERE id=?", (i,))
                self.conn.execute("COMMIT")
            except Exception:
                self.conn.execute("ROLLBACK")
                raise
            return ids

    def add_email(self, company_id: int, email: str, kind: str, source: str = "") -> None:
        self.x("INSERT OR IGNORE INTO emails(company_id,email,kind,source) VALUES(?,?,?,?)",
               (company_id, email.lower(), kind, source))

    # ---- outbox / send queue ----------------------------------------------
    def add_draft(self, company_id, to_email, subject, body, lang, kind="initial",
                  parent_id=None, status="draft") -> int | None:
        """Returns the new id, or None if this address already has a live initial mail."""
        try:
            cur = self.x(
                "INSERT INTO outbox(company_id,to_email,subject,body,lang,kind,parent_id,status,"
                "created_at,approved_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (company_id, to_email.lower(), subject, body, lang, kind, parent_id, status,
                 utcnow(), utcnow() if status == "approved" else None),
            )
            return cur.lastrowid
        except sqlite3.IntegrityError:
            return None

    def get_outbox(self, rid: int):
        return self.one("SELECT * FROM outbox WHERE id=?", (rid,))

    def set_outbox(self, rid: int, **f) -> None:
        f = {k: v for k, v in f.items() if k in OUTBOX_FIELDS}
        if not f:
            return
        cols = ", ".join(f"{k}=?" for k in f)
        self.x(f"UPDATE outbox SET {cols} WHERE id=?", (*f.values(), rid))

    def approve(self, rid: int) -> bool:
        cur = self.x("UPDATE outbox SET status='approved', approved_at=? "
                     "WHERE id=? AND status='draft'", (utcnow(), rid))
        return cur.rowcount > 0

    def skip(self, rid: int) -> bool:
        cur = self.x("UPDATE outbox SET status='skipped' WHERE id=? AND status IN "
                     "('draft','approved')", (rid,))
        return cur.rowcount > 0

    def claim_next_to_send(self) -> int | None:
        """Atomically moves ONE approved mail to 'sending'. Two workers can never get the same row."""
        with self.lock:
            self.conn.execute("BEGIN IMMEDIATE")
            try:
                row = self.conn.execute(
                    "SELECT id FROM outbox WHERE status='approved' "
                    "AND (next_try_at IS NULL OR next_try_at<=?) ORDER BY approved_at, id LIMIT 1",
                    (utcnow(),),
                ).fetchone()
                rid = None
                if row:
                    rid = row["id"]
                    self.conn.execute(
                        "UPDATE outbox SET status='sending', attempts=attempts+1 WHERE id=?", (rid,))
                self.conn.execute("COMMIT")
                return rid
            except Exception:
                self.conn.execute("ROLLBACK")
                raise

    def recover_stuck_sending(self) -> int:
        """After a crash we can't know if a 'sending' mail left the building. Never resend blindly."""
        cur = self.x("UPDATE outbox SET status='needs_review', "
                     "last_error='interrupted while sending - check Gmail Sent folder' "
                     "WHERE status='sending'")
        return cur.rowcount

    def sent_today(self, tzname: str) -> int:
        tz = ZoneInfo(tzname)
        start = datetime.now(tz).replace(hour=0, minute=0, second=0, microsecond=0)
        start_utc = start.astimezone(timezone.utc).strftime(FMT)
        return self.one("SELECT COUNT(*) c FROM outbox WHERE sent_at>=?", (start_utc,))["c"]

    # ---- suppression list ---------------------------------------------------
    def suppress(self, email: str, reason: str = "") -> None:
        self.x("INSERT OR IGNORE INTO suppression(email,reason,created_at) VALUES(?,?,?)",
               (email.lower().strip(), reason, utcnow()))

    def is_suppressed(self, email: str) -> bool:
        email = email.lower().strip()
        dom = email.split("@")[-1]
        return bool(self.one("SELECT 1 FROM suppression WHERE email=? OR email=?", (email, "@" + dom)))
