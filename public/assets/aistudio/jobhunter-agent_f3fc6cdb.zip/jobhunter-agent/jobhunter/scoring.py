"""Sponsor Score: a transparent 0-100 heuristic. It is NOT a guarantee of sponsorship."""
from __future__ import annotations

import socket

from .data import HIGH_DEMAND


def check_mx(domain: str) -> bool:
    """True if the domain can receive email (MX record, or at least an A record)."""
    if not domain:
        return False
    try:
        import dns.resolver  # type: ignore

        try:
            return len(dns.resolver.resolve(domain, "MX", lifetime=8)) > 0
        except Exception:
            pass
    except ImportError:
        pass
    try:
        socket.getaddrinfo(domain, None)
        return True
    except OSError:
        return False


def label(score: int) -> str:
    return "Strong" if score >= 70 else "Maybe" if score >= 45 else "Weak"


def score_company(i: dict) -> tuple[int, list[str]]:
    s, why = 0, []

    def add(p: int, text: str):
        nonlocal s
        s += p
        why.append(f"{p:+d} {text}")

    if i.get("reachable"):
        add(10, "website reachable")
    if i.get("has_job"):
        add(25, "relevant job posted")
    v = i.get("visa_signal")
    if v == "explicit":
        add(25, "mentions visa / work permit / non-EU hiring")
    elif v == "implicit":
        add(10, "mentions accommodation / relocation / international team")
    elif v == "negative":
        add(-35, "says EU citizens / existing right to work only")
    if i.get("accommodation"):
        add(5, "staff accommodation mentioned")
    if i.get("best_email"):
        add(5, "contact email found")
        add(10, "email domain matches website") if i.get("email_matches_site") else add(-10, "email domain differs from website")
        if i.get("email_kind") == "hr":
            add(5, "HR / careers mailbox")
        if i.get("freemail"):
            add(-10, "free-mail address")
        add(5, "email domain accepts mail") if i.get("mx_ok") else add(-15, "email domain cannot receive mail")
    else:
        add(-20, "no email found")
    if i.get("has_contact_details"):
        add(5, "phone / address listed")
    if i.get("country") in HIGH_DEMAND:
        add(5, "country where many employers hire foreign hospitality staff")
    for f in i.get("red_flags") or []:
        add(-40, f"red flag: {f}")
    return max(0, min(100, s)), why
