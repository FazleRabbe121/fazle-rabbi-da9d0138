"""Static data: countries, keywords in many languages, heuristics."""
from __future__ import annotations

# ISO code -> (country name, language used for the email draft)
COUNTRIES = {
    "HR": ("Croatia", "Croatian"), "MT": ("Malta", "English"), "PL": ("Poland", "Polish"),
    "RO": ("Romania", "Romanian"), "CZ": ("Czechia", "Czech"), "LT": ("Lithuania", "English"),
    "LV": ("Latvia", "English"), "EE": ("Estonia", "English"), "BG": ("Bulgaria", "Bulgarian"),
    "HU": ("Hungary", "Hungarian"), "SK": ("Slovakia", "Slovak"), "SI": ("Slovenia", "Slovenian"),
    "DE": ("Germany", "German"), "AT": ("Austria", "German"), "NL": ("Netherlands", "English"),
    "BE": ("Belgium", "English"), "IE": ("Ireland", "English"), "IT": ("Italy", "Italian"),
    "ES": ("Spain", "Spanish"), "PT": ("Portugal", "Portuguese"), "FR": ("France", "French"),
    "GR": ("Greece", "English"), "CY": ("Cyprus", "English"), "DK": ("Denmark", "English"),
    "SE": ("Sweden", "English"), "FI": ("Finland", "English"), "NO": ("Norway", "English"),
    "CH": ("Switzerland", "German"), "LU": ("Luxembourg", "French"), "IS": ("Iceland", "English"),
}

# Heuristic only: countries where hospitality employers often hire from abroad.
# Rules change - edit this list as you learn more. It only adds a small score bonus.
HIGH_DEMAND = {"HR", "MT", "PL", "RO", "CZ", "LT", "LV", "EE", "BG", "HU", "SK", "SI"}

# Normalised (lowercase, separators as spaces) words that signal a careers page link.
CAREER_KEYWORDS = [
    "career", "careers", "jobs", "job", "vacancies", "vacancy", "work with us", "join us",
    "join our team", "join the team", "employment", "recruitment", "hiring", "work for us",
    "karriere", "stellenangebote", "stellen", "jobangebote", "arbeiten bei", "offene stellen",
    "lavora con noi", "lavoro", "offerte di lavoro", "carriere", "posizioni aperte",
    "trabaja con nosotros", "empleo", "trabajo", "ofertas de empleo", "carrière", "emplois",
    "recrutement", "offres d emploi", "nous rejoindre", "kariera", "praca", "oferty pracy",
    "rekrutacja", "posao", "karijera", "zaposlenje", "slobodna radna mjesta", "cariere",
    "joburi", "angajari", "kariéra", "práce", "volná místa", "karrier", "állás",
    "darbas", "karjeras", "töö", "работа", "кариери", "свободни позиции",
    "vacatures", "werken bij", "carreiras", "emprego", "trabalhe connosco", "karriär",
    "lediga jobb", "ledige stillinger", "rekrytering", "työpaikat", "θέσεις εργασίας",
    "καριέρα",
]

CONTACT_KEYWORDS = [
    "contact", "contact us", "kontakt", "impressum", "contatti", "contacto", "contactez",
    "kontakty", "kontakti", "contacte", "kapcsolat", "kontaktai", "επικοινωνία", "контакти",
]

ATS_DOMAINS = (
    "greenhouse.io", "lever.co", "workable.com", "personio.de", "personio.com", "recruitee.com",
    "teamtailor.com", "smartrecruiters.com", "bamboohr.com", "join.com", "jobs.ch",
    "hotelcareer.com", "hosco.com", "softgarden.io", "breezy.hr", "applytojob.com",
)

# Role words in many languages (matched as whole words, case-insensitive)
ROLE_WORDS = [
    "bartender", "barman", "barmaid", "barista", "waiter", "waitress", "bar staff",
    "restaurant staff", "food and beverage", "food & beverage", "f&b", "server",
    "kellner", "kellnerin", "barkeeper", "servicekraft", "servicemitarbeiter", "barmitarbeiter",
    "cameriere", "cameriera", "banconiere", "camarero", "camarera", "garçon",
    "serveur", "serveuse", "kelner", "kelnerka", "konobar", "konobarica", "šanker",
    "ospătar", "chelner", "čašník", "číšník", "servírka", "pincér", "pultos",
    "padavėjas", "bārmenis", "viesmīlis", "ettekandja", "сервитьор", "барман", "ober",
    "serveerster", "bediening", "empregado de mesa", "empregado de bar", "garçom",
    "σερβιτόρος", "σερβιτόρα", "μπάρμαν",
]

HIRING_WORDS = [
    "we are hiring", "we're hiring", "now hiring", "join our team", "open positions", "vacancy",
    "vacancies", "apply now", "apply", "job offer", "we are looking for", "we're looking for",
    "looking for", "stellenangebot", "wir suchen", "bewirb", "cerchiamo", "stiamo cercando",
    "buscamos", "nous recherchons", "poszukujemy", "tražimo", "traži se", "căutăm", "hledáme",
    "keresünk", "ищем", "търсим",
]

VISA_EXPLICIT = [
    "visa sponsorship", "sponsor visa", "visa support", "visa assistance", "we sponsor",
    "sponsorship available", "work permit", "work visa", "non eu", "non-eu", "third country",
    "third-country", "arbeitserlaubnis", "arbeitsvisum", "visum", "permis de travail",
    "permesso di lavoro", "permiso de trabajo", "dozvola za rad", "radna dozvola",
    "zezwolenie na pracę", "permis de muncă", "povolení k pobytu",
]
VISA_IMPLICIT = [
    "relocation", "relocate", "accommodation", "housing", "staff housing", "international team",
    "international candidates", "unterkunft", "personalunterkunft", "logement", "alloggio",
    "alojamiento", "smještaj", "smjestaj", "zakwaterowanie", "cazare", "ubytování", "szállás",
]
VISA_NEGATIVE = [
    "no sponsorship", "unable to sponsor", "cannot sponsor", "not able to sponsor",
    "eu citizens only", "eu/eea citizens only", "must have the right to work",
    "must already have the right to work", "must already hold a valid work permit",
    "only candidates with eu", "nur eu", "keine visa",
]
FEE_WORDS = [
    "registration fee", "processing fee", "application fee", "pay for visa", "western union",
    "moneygram", "send money", "deposit required", "visa fee payable", "agency fee", "pay a fee",
]

FREEMAIL = {
    "gmail.com", "googlemail.com", "yahoo.com", "yahoo.de", "yahoo.it", "hotmail.com",
    "outlook.com", "live.com", "icloud.com", "aol.com", "gmx.de", "gmx.net", "gmx.at",
    "web.de", "proton.me", "protonmail.com", "mail.ru", "yandex.com", "yandex.ru", "abv.bg",
    "wp.pl", "o2.pl", "seznam.cz", "t-online.de", "libero.it", "alice.it", "orange.fr",
    "wanadoo.fr", "free.fr", "sapo.pt", "hotmail.it", "hotmail.es", "hotmail.fr",
}

HR_LOCALS = {
    "hr", "jobs", "job", "career", "careers", "recruitment", "recruiting", "karriere",
    "bewerbung", "bewerbungen", "personal", "lavora", "lavoraconnoi", "rrhh", "empleo",
    "praca", "kadry", "posao", "karijera", "work", "hiring", "humanresources", "people",
}
GENERAL_LOCALS = {
    "info", "contact", "kontakt", "hello", "hallo", "office", "mail", "reception", "recepcija",
    "rezervacije", "reservations", "booking", "welcome", "hotel", "admin", "contacto", "contatti",
}
