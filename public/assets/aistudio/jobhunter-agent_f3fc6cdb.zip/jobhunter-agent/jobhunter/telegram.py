"""Minimal Telegram Bot API client (long polling) - no extra library needed."""
from __future__ import annotations

import logging

log = logging.getLogger("telegram")


class Telegram:
    def __init__(self, cfg, client):
        self.cfg, self.client = cfg, client
        self.base = f"https://api.telegram.org/bot{cfg.telegram_token}"

    async def call(self, method: str, **payload):
        try:
            r = await self.client.post(f"{self.base}/{method}", json=payload, timeout=70)
            data = r.json()
        except Exception as e:
            log.warning("telegram %s failed: %s", method, e)
            return None
        if not data.get("ok"):
            log.warning("telegram %s error: %s", method, data.get("description"))
            return None
        return data.get("result")

    async def send(self, text: str, buttons=None, chat_id: int | None = None):
        chat = chat_id or self.cfg.telegram_chat_id
        if not chat or not self.cfg.telegram_token:
            log.info("[telegram disabled] %s", text[:120])
            return None
        payload = {"chat_id": chat, "text": text[:4000], "disable_web_page_preview": True}
        if buttons:
            payload["reply_markup"] = {"inline_keyboard": buttons}
        return await self.call("sendMessage", **payload)

    async def clear_buttons(self, chat_id: int, message_id: int):
        await self.call("editMessageReplyMarkup", chat_id=chat_id, message_id=message_id,
                        reply_markup={"inline_keyboard": []})

    async def answer(self, callback_id: str, text: str = ""):
        await self.call("answerCallbackQuery", callback_query_id=callback_id, text=text[:180])

    async def send_document(self, path: str, caption: str = ""):
        try:
            with open(path, "rb") as f:
                r = await self.client.post(
                    f"{self.base}/sendDocument", data={"chat_id": str(self.cfg.telegram_chat_id), "caption": caption},
                    files={"document": (path.split("/")[-1], f)}, timeout=120)
            return r.json().get("ok", False)
        except Exception as e:
            log.warning("sendDocument failed: %s", e)
            return False

    async def get_updates(self, offset: int):
        return await self.call("getUpdates", offset=offset, timeout=50,
                               allowed_updates=["message", "callback_query"]) or []
