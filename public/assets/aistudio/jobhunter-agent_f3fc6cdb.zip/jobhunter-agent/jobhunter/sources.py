"""Company discovery: OpenStreetMap (free, no key) and Google Places (optional key)."""
from __future__ import annotations

import asyncio
import logging
import re

from .data import COUNTRIES
from .textutil import domain_of, normalize_website

log = logging.getLogger("sources")
OVERPASS = ["https://overpass-api.de/api/interpreter", "https://overpass.kumi.systems/api/interpreter"]


def _clean_city(city: str) -> str:
    return re.sub(r"[^\w\s\-\.']", "", city, flags=re.U).strip()


def build_overpass_query(city: str, kinds: str = "hotels", limit: int = 400) -> str:
    c = re.escape(_clean_city(city))
    parts = [
        'nwr["tourism"~"^(hotel|resort|guest_house|hostel|motel|apartment)$"]["website"](area.a);',
        'nwr["tourism"~"^(hotel|resort|guest_house|hostel|motel|apartment)$"]["contact:website"](area.a);',
    ]
    if kinds == "all":
        parts += [
            'nwr["amenity"~"^(restaurant|bar|cafe|pub|biergarten)$"]["website"](area.a);',
            'nwr["amenity"~"^(restaurant|bar|cafe|pub|biergarten)$"]["contact:website"](area.a);',
        ]
    body = "\n  ".join(parts)
    return (
        f'[out:json][timeout:90];\n'
        f'area[~"^name(:en)?$"~"^{c}$",i]["boundary"="administrative"]->.a;\n'
        f'(\n  {body}\n);\nout tags center {limit};'
    )


def parse_overpass(data: dict, city: str, cc: str) -> list[dict]:
    out, seen = [], set()
    for el in data.get("elements", []):
        t = el.get("tags", {})
        site = normalize_website(t.get("website") or t.get("contact:website") or t.get("url") or "")
        name = t.get("name")
        if not site or not name:
            continue
        dom = domain_of(site)
        if dom in seen or any(b in dom for b in ("facebook.com", "instagram.com", "booking.com", "tripadvisor", "airbnb")):
            continue
        seen.add(dom)
        addr = " ".join(x for x in (t.get("addr:street"), t.get("addr:housenumber")) if x)
        out.append({
            "name": name, "website": site, "domain": dom, "country": cc, "city": t.get("addr:city") or city,
            "address": addr, "phone": t.get("phone") or t.get("contact:phone") or "",
            "osm_email": (t.get("email") or t.get("contact:email") or "").lower(), "source": "osm",
        })
    return out


async def overpass_search(client, city: str, cc: str, kinds: str = "hotels") -> list[dict]:
    query = build_overpass_query(city, kinds)
    last = None
    for attempt in range(3):
        ep = OVERPASS[attempt % len(OVERPASS)]
        try:
            r = await client.post(ep, data={"data": query}, timeout=120)
            if r.status_code == 200:
                return parse_overpass(r.json(), city, cc)
            last = f"HTTP {r.status_code}"
        except Exception as e:
            last = str(e)
        await asyncio.sleep(5 * (attempt + 1))
    log.warning("Overpass failed for %s: %s", city, last)
    return []


async def places_search(client, key: str, city: str, cc: str, kinds: str = "hotels") -> list[dict]:
    """Google Places API (New) text search - up to 60 results per query. Needs GOOGLE_PLACES_API_KEY."""
    if not key:
        return []
    country = COUNTRIES.get(cc, (cc, ""))[0]
    queries = ["hotels"] + (["restaurants", "bars"] if kinds == "all" else [])
    out, seen = [], set()
    for what in queries:
        token = None
        for _ in range(3):
            body = {"textQuery": f"{what} in {city}, {country}", "pageSize": 20}
            if token:
                body["pageToken"] = token
            try:
                r = await client.post(
                    "https://places.googleapis.com/v1/places:searchText", json=body, timeout=30,
                    headers={"X-Goog-Api-Key": key, "X-Goog-FieldMask":
                             "places.displayName,places.websiteUri,places.formattedAddress,"
                             "places.nationalPhoneNumber,nextPageToken"},
                )
            except Exception as e:
                log.warning("Places error: %s", e)
                break
            if r.status_code != 200:
                log.warning("Places HTTP %s %s", r.status_code, r.text[:200])
                break
            data = r.json()
            for p in data.get("places", []):
                site = normalize_website(p.get("websiteUri", ""))
                name = (p.get("displayName") or {}).get("text")
                if not site or not name:
                    continue
                dom = domain_of(site)
                if dom in seen or any(b in dom for b in ("facebook.com", "instagram.com", "booking.com", "tripadvisor")):
                    continue
                seen.add(dom)
                out.append({"name": name, "website": site, "domain": dom, "country": cc, "city": city,
                            "address": p.get("formattedAddress", ""), "phone": p.get("nationalPhoneNumber", ""),
                            "osm_email": "", "source": "places"})
            token = data.get("nextPageToken")
            if not token:
                break
            await asyncio.sleep(1.5)
    return out
