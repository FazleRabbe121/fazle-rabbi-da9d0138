"""Tiny Gemini REST client with a daily call budget and retry/backoff."""
from __future__ import annotations

import asyncio
import json
import logging
import re
from datetime import datetime, timezone

log = logging.getLogger("gemini")


def _parse_json(txt: str):
    txt = txt.strip()
    txt = re.sub(r"^```(?:json)?\s*|\s*```$", "", txt, flags=re.I)
    try:
        return json.loads(txt)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", txt, flags=re.S)
        if m:
            try:
                return json.loads(m.group(0))
            except json.JSONDecodeError:
                return None
    return None


async def generate_json(cfg, db, client, prompt: str) -> dict | None:
    """Returns a dict, or None when Gemini is unavailable (callers must have a fallback)."""
    if not cfg.gemini_key:
        return None
    day = datetime.now(timezone.utc).strftime("%Y%m%d")
    key = f"gemini_calls_{day}"
    used = int(db.kv_get(key, "0") or 0)
    if used >= cfg.gemini_daily_calls:
        log.info("Gemini daily budget reached (%s)", used)
        return None
    db.kv_set(key, str(used + 1))

    url = f"https://generativelanguage.googleapis.com/v1beta/models/{cfg.gemini_model}:generateContent"
    body = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.3, "responseMimeType": "application/json"},
    }
    for attempt in range(4):
        try:
            r = await client.post(url, json=body, headers={"x-goog-api-key": cfg.gemini_key}, timeout=60)
        except Exception as e:  # network error
            log.warning("Gemini network error: %s", e)
            await asyncio.sleep(3 * (attempt + 1))
            continue
        if r.status_code in (429, 500, 502, 503, 504):
            await asyncio.sleep(4 * 2 ** attempt)
            continue
        if r.status_code != 200:
            log.warning("Gemini HTTP %s: %s", r.status_code, r.text[:200])
            return None
        try:
            txt = r.json()["candidates"][0]["content"]["parts"][0]["text"]
        except Exception:
            return None
        return _parse_json(txt)
    return None
