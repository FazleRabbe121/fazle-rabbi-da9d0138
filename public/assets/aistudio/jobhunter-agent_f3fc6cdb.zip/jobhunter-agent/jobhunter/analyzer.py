"""Decides whether a company page has a real, relevant job. Rules first, Gemini on top."""
from __future__ import annotations

import re

from .data import (FEE_WORDS, HIRING_WORDS, ROLE_WORDS, VISA_EXPLICIT, VISA_IMPLICIT,
                   VISA_NEGATIVE)
from .gemini import generate_json

ROLE_RE = re.compile(
    r"(?<!\w)(" + "|".join(sorted((re.escape(w) for w in set(ROLE_WORDS)), key=len, reverse=True)) + r")(?!\w)",
    re.I,
)
HIRING_RE = re.compile(
    r"(?<!\w)(" + "|".join(sorted((re.escape(w) for w in set(HIRING_WORDS)), key=len, reverse=True)) + r")",
    re.I,
)


def rule_analyze(text: str) -> dict:
    t = text.lower()
    roles = sorted({m.lower() for m in ROLE_RE.findall(t)})
    # "server" alone is too ambiguous (IT servers) - require another role word or hospitality context
    if roles == ["server"] and not re.search(r"restaurant|hotel|bar |café|cafe|guest", t):
        roles = []
    has_job = bool(roles) and bool(HIRING_RE.search(t))
    if any(k in t for k in VISA_NEGATIVE):
        visa = "negative"
    elif any(k in t for k in VISA_EXPLICIT):
        visa = "explicit"
    elif any(k in t for k in VISA_IMPLICIT):
        visa = "implicit"
    else:
        visa = "none"
    accommodation = any(k in t for k in ("accommodation", "housing", "unterkunft", "logement",
                                         "alloggio", "alojamiento", "smještaj", "zakwaterowanie"))
    flags = [f for f in FEE_WORDS if f in t]
    return {"has_relevant_job": has_job, "roles": roles[:6], "visa_signal": visa,
            "accommodation": accommodation, "apply_email": None, "apply_url": None,
            "language": "", "red_flags": flags, "summary": ""}


PROMPT = """You are helping a hospitality worker find REAL job openings.
Below is text from a hotel/restaurant website (careers or home page; any language).
Return ONLY a JSON object with these keys:
  has_relevant_job: true if there is an open position for bartender, barista, waiter/waitress or bar/restaurant service staff
  roles: list of short role names found (English)
  visa_signal: "explicit" if the page says they help with visa/work permit or accept non-EU applicants;
               "implicit" if it mentions staff accommodation, relocation or an international team;
               "negative" if it says only EU citizens / existing right to work; otherwise "none"
  accommodation: true/false
  apply_email: an email address explicitly given for job applications, or null
  apply_url: an application URL explicitly given, or null
  language: ISO 639-1 code of the page language
  red_flags: list of strings (asks applicants to pay money, looks like a scam, etc.) - empty if none
  summary: one short English sentence
Never invent anything. If the page has no job information set has_relevant_job to false.

PAGE TEXT:
"""


async def analyze(cfg, db, client, text: str) -> dict:
    base = rule_analyze(text)
    if not text.strip():
        return base
    data = await generate_json(cfg, db, client, PROMPT + text[:9000])
    if not isinstance(data, dict):
        return base
    out = dict(base)
    out["has_relevant_job"] = bool(data.get("has_relevant_job", base["has_relevant_job"]))
    roles = data.get("roles") or base["roles"]
    out["roles"] = [str(r).lower() for r in roles][:6] if isinstance(roles, list) else base["roles"]
    v = str(data.get("visa_signal", "")).lower()
    if v in ("explicit", "implicit", "negative", "none"):
        # never let the model hide a rule-detected negative or scam flag
        out["visa_signal"] = "negative" if base["visa_signal"] == "negative" else v
    out["accommodation"] = bool(data.get("accommodation", base["accommodation"]))
    for k in ("apply_email", "apply_url", "language", "summary"):
        val = data.get(k)
        out[k] = val if isinstance(val, str) and val.strip() and val.lower() != "null" else base.get(k)
    flags = data.get("red_flags") or []
    out["red_flags"] = sorted(set(base["red_flags"]) | {str(f) for f in flags if str(f).strip()})
    return out
