/* Generator page: form -> live certificate preview -> Download PDF (browser print dialog). */
(function () {
  var C = window.CERT_CONFIG, $ = function (id) { return document.getElementById(id); };
  var current = null;

  C.PROGRAMS.forEach(function (p) { $('program').add(new Option(p.name, p.id)); });
  $('date').value = new Date().toISOString().slice(0, 10);

  function fillLevels() {
    var p = Certificate.program($('program').value); $('level').innerHTML = '';
    p.levels.forEach(function (l, i) { $('level').add(new Option('Level ' + (i + 1) + ' — ' + l.award, i + 1)); });
  }

  function fit() {
    var h = $('holder'), s = Math.min(1, ($('stage').clientWidth - 56) / 1123);
    h.style.transform = 'scale(' + s + ')'; $('stage').style.height = (794 * s + 48) + 'px';
  }

  function generate(keepId) {
    var name = $('name').value.trim(); if (!name) { $('name').focus(); return; }
    current = Certificate.create({ name: name, programId: $('program').value, level: $('level').value,
      issuedAt: $('date').value, id: keepId && current ? current.id : '' });
    $('holder').innerHTML = Certificate.render(current);
    $('idline').innerHTML = 'Certificate ID: <b>' + current.id + '</b>';
    fit();
  }

  $('program').addEventListener('change', fillLevels);
  $('gen').addEventListener('click', function () { generate(false); });
  ['name', 'level', 'date'].forEach(function (id) { $(id).addEventListener('change', function () { if (current) generate(true); }); });
  $('print').addEventListener('click', function () { if (!current) generate(false); if (current) window.print(); });
  window.addEventListener('resize', fit);

  fillLevels();
  $('name').value = 'Fazle Rabbi'; generate(false);   // sample shown on first load
})();
