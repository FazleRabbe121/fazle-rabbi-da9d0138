/* Core certificate logic. No dependencies except js/config.js, js/template.js, js/qrcode.js.
 *
 *   Certificate.create({ name, programId, level, issuedAt })  -> data object (adds the unique id)
 *   Certificate.render(data)                                  -> HTML string of the certificate
 *   Certificate.verifyUrl(data)                               -> link stored inside the QR code
 *   Certificate.decode(hash)                                  -> data from an embedded-mode link
 */
(function () {
  var C = window.CERT_CONFIG, T = window.CERT_TEMPLATE;
  var esc = function (s) { return String(s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };

  function program(id) { return C.PROGRAMS.filter(function (p) { return p.id === id; })[0]; }

  /* Unique ID: BLV-XXXXXXXX-YYYY  (no look-alike characters such as 0/O or 1/I) */
  function newId(year) {
    var chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789', out = '', r = new Uint32Array(8);
    crypto.getRandomValues(r);
    for (var i = 0; i < 8; i++) out += chars[r[i] % chars.length];
    return 'BLV-' + out + '-' + year;
  }

  function create(input) {
    var p = program(input.programId), lv = p.levels[input.level - 1];
    var date = input.issuedAt || new Date().toISOString().slice(0, 10);
    return {
      id: input.id || newId(date.slice(0, 4)),
      name: input.name.trim(), programId: p.id, programName: p.name,
      level: +input.level, award: lv.award, issuedAt: date
    };
  }

  function fmtDate(iso) { var d = iso.split('-'); return d[2] + '.' + d[1] + '.' + d[0]; }

  function b64url(s) { return btoa(unescape(encodeURIComponent(s))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
  function unb64url(s) { s = s.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; return decodeURIComponent(escape(atob(s))); }

  function verifyUrl(d) {
    if (C.VERIFY_MODE === 'database') return C.DATABASE_VERIFY_URL.replace(/\/$/, '') + '/' + d.id;
    var base = C.SITE_URL ? C.SITE_URL.replace(/\/?$/, '/') : new URL('./', location.href).href;
    var payload = { n: d.name, p: d.programName, l: d.level, a: d.award, d: d.issuedAt, i: d.id };
    return base + 'verify.html?id=' + d.id + '#' + b64url(JSON.stringify(payload));
  }

  function decode(hash) {
    try { var o = JSON.parse(unb64url(hash.replace(/^#/, '')));
      return { name: o.n, programName: o.p, level: o.l, award: o.a, issuedAt: o.d, id: o.i }; }
    catch (e) { return null; }
  }

  function qrSvg(text) {
    var q = new QRLib.QRCode(-1, QRLib.ECL.M); q.addData(text); q.make();
    var n = q.getModuleCount(), r = '';
    for (var y = 0; y < n; y++) for (var x = 0; x < n; x++)
      if (q.isDark(y, x)) r += '<rect x="' + x + '" y="' + y + '" width="1.02" height="1.02"/>';
    return '<svg viewBox="0 0 ' + n + ' ' + n + '" shape-rendering="crispEdges" fill="#111">' + r + '</svg>';
  }

  function render(d) {
    var award = esc(d.award).replace(/\(([^)]*)\)/, '<small>($1)</small>');
    var name = esc(d.name), nameStyle = d.name.length > 28 ? ' style="font-size:34px"' : '';
    var html = T.body
      .replace('<div class="name">', '<div class="name"' + nameStyle + '>')
      .replace('__NAME__', name)
      .replace('__TITLE__', award)
      .replace('__SENTENCE__', 'Level ' + d.level + ' ' + esc(d.programName) + ' assessment')
      .replace('__ID__', esc(d.id))
      .replace('__HOST__', esc(C.SITE_HOST))
      .replace('__DIRECTOR__', esc(C.DIRECTOR_NAME))
      .replace('__STAMP__', T.stamp.replace('__DATE__', fmtDate(d.issuedAt)))
      .replace('__SIGN__', T.sign)
      .replace('__SEAL__', T.seal)
      .replace('__QR__', qrSvg(verifyUrl(d)));
    return html;
  }

  window.Certificate = { create: create, render: render, verifyUrl: verifyUrl, decode: decode, fmtDate: fmtDate, program: program };
})();
