/* Certificate HTML template. Tokens in __DOUBLE_UNDERSCORES__ are replaced by js/certificate.js */
window.CERT_TEMPLATE = {
  body: `<div class="cert" id="cert">
  <div class="frame"></div>
  <svg class="wm" viewBox="0 0 1123 794" aria-hidden="true">
  <defs><pattern id="wmp" width="320" height="90" patternUnits="userSpaceOnUse" patternTransform="rotate(-24)">
    <text x="6" y="50" class="wmt">BELVORINÉ MIXOLOGY</text></pattern></defs>
  <rect width="1123" height="794" fill="url(#wmp)"/>
  <g transform="translate(561 400) scale(1.55)" fill="none" stroke="#c8102e" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round" opacity=".075">
    <circle r="150" stroke-width="1.6"/><circle r="142" stroke-width=".8"/>
    <path d="M-78,-78 L78,-78 L0,2 Z"/><path d="M-60,-62 L60,-62" /><path d="M0,2 V82"/><ellipse cx="0" cy="86" rx="36" ry="7"/>
    <circle cx="22" cy="-40" r="9"/><path d="M12,-62 L34,-30"/>
  </g>
</svg>
  <div class="inner">
    <div class="brand">BELVORINÉ</div>
    <div class="sub"><i></i>MIXOLOGY<i></i></div>
    <h1>Certificate of Achievement</h1>
    <div class="lead">This is to certify that</div>
    <div class="name">__NAME__</div>
    <div class="txt">has successfully completed the Belvoriné Mixology<br>__SENTENCE__ and has been awarded a certificate in</div>
    <div class="award">__TITLE__</div>
  </div>
  <div class="bottom">
    <div class="cell">__STAMP__</div>
    <div class="cell">__SIGN__<div class="line"></div><div class="pname">__DIRECTOR__</div><div class="prole">Program Director</div></div>
    <div class="cell">__SEAL__</div>
    <div class="cell"><div class="idbox">__ID__</div><div class="line"></div>Certificate ID</div>
    <div class="qr"><div class="code">__QR__</div><div class="v"><b>Verify certificate</b><br>Scan QR or visit<br>__HOST__/verify</div></div>
  </div>
</div>`,
  stamp: `<svg class="stamp" viewBox="-80 -80 160 160" aria-label="Issue date stamp">
  <defs>
    <path id="arcTop" d="M -52,0 A 52,52 0 0 1 52,0"/>
    <path id="arcBot" d="M -60,0 A 60,60 0 0 0 60,0"/>
    <filter id="ink" x="-5%" y="-5%" width="110%" height="110%">
      <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="4" result="n"/>
      <feDisplacementMap in="SourceGraphic" in2="n" scale="1.6"/>
    </filter>
  </defs>
  <g filter="url(#ink)" fill="none" stroke="#26418f" opacity=".86" transform="rotate(-9)">
    <circle r="74" stroke-width="3"/>
    <circle r="68" stroke-width="1"/>
    <circle r="44" stroke-width="1"/>
    <g fill="#26418f" stroke="none">
      <text class="st-arc" text-anchor="middle"><textPath href="#arcTop" startOffset="50%" transform="translate(0,0)">BELVORINÉ MIXOLOGY</textPath></text>
      <text class="st-arc" text-anchor="middle" transform="translate(0,2)"><textPath href="#arcBot" startOffset="50%" side="left">CERTIFICATION</textPath></text>
      <text x="0" y="-4" text-anchor="middle" class="st-date">__DATE__</text>
      <text x="0" y="14" text-anchor="middle" class="st-lab">Issue Date</text>
      <path d="M0 24 l2.4 5 5.4.7-4 3.7 1 5.3-4.8-2.6-4.8 2.6 1-5.3-4-3.7 5.4-.7z" transform="translate(0,2) scale(.8)"/>
    </g>
  </g>
</svg>`,
  seal: `<svg class="seal" viewBox="-70 -70 140 140" aria-label="Verified certificate">
  <g fill="#b9b2ad" opacity=".95"><ellipse cx="-11.9" cy="44.4" rx="2.8" ry="7.5" transform="rotate(77 -11.9 44.4)"/><ellipse cx="-13.5" cy="50.2" rx="2.8" ry="7.5" transform="rotate(133 -13.5 50.2)"/><ellipse cx="-21.2" cy="40.8" rx="2.8" ry="7.5" transform="rotate(90 -21.2 40.8)"/><ellipse cx="-24.0" cy="46.1" rx="2.8" ry="7.5" transform="rotate(146 -24.0 46.1)"/><ellipse cx="-29.6" cy="35.2" rx="2.8" ry="7.5" transform="rotate(102 -29.6 35.2)"/><ellipse cx="-33.4" cy="39.8" rx="2.8" ry="7.5" transform="rotate(158 -33.4 39.8)"/><ellipse cx="-36.5" cy="28.0" rx="2.8" ry="7.5" transform="rotate(114 -36.5 28.0)"/><ellipse cx="-41.3" cy="31.7" rx="2.8" ry="7.5" transform="rotate(170 -41.3 31.7)"/><ellipse cx="-41.7" cy="19.4" rx="2.8" ry="7.5" transform="rotate(127 -41.7 19.4)"/><ellipse cx="-47.1" cy="22.0" rx="2.8" ry="7.5" transform="rotate(183 -47.1 22.0)"/><ellipse cx="-44.9" cy="10.0" rx="2.8" ry="7.5" transform="rotate(140 -44.9 10.0)"/><ellipse cx="-50.8" cy="11.3" rx="2.8" ry="7.5" transform="rotate(196 -50.8 11.3)"/><ellipse cx="-46.0" cy="0.0" rx="2.8" ry="7.5" transform="rotate(152 -46.0 0.0)"/><ellipse cx="-52.0" cy="0.0" rx="2.8" ry="7.5" transform="rotate(208 -52.0 0.0)"/><ellipse cx="-44.9" cy="-10.0" rx="2.8" ry="7.5" transform="rotate(164 -44.9 -10.0)"/><ellipse cx="-50.8" cy="-11.3" rx="2.8" ry="7.5" transform="rotate(220 -50.8 -11.3)"/><ellipse cx="-41.7" cy="-19.4" rx="2.8" ry="7.5" transform="rotate(177 -41.7 -19.4)"/><ellipse cx="-47.1" cy="-22.0" rx="2.8" ry="7.5" transform="rotate(233 -47.1 -22.0)"/><g transform="scale(-1 1)"><ellipse cx="-11.9" cy="44.4" rx="2.8" ry="7.5" transform="rotate(77 -11.9 44.4)"/><ellipse cx="-13.5" cy="50.2" rx="2.8" ry="7.5" transform="rotate(133 -13.5 50.2)"/><ellipse cx="-21.2" cy="40.8" rx="2.8" ry="7.5" transform="rotate(90 -21.2 40.8)"/><ellipse cx="-24.0" cy="46.1" rx="2.8" ry="7.5" transform="rotate(146 -24.0 46.1)"/><ellipse cx="-29.6" cy="35.2" rx="2.8" ry="7.5" transform="rotate(102 -29.6 35.2)"/><ellipse cx="-33.4" cy="39.8" rx="2.8" ry="7.5" transform="rotate(158 -33.4 39.8)"/><ellipse cx="-36.5" cy="28.0" rx="2.8" ry="7.5" transform="rotate(114 -36.5 28.0)"/><ellipse cx="-41.3" cy="31.7" rx="2.8" ry="7.5" transform="rotate(170 -41.3 31.7)"/><ellipse cx="-41.7" cy="19.4" rx="2.8" ry="7.5" transform="rotate(127 -41.7 19.4)"/><ellipse cx="-47.1" cy="22.0" rx="2.8" ry="7.5" transform="rotate(183 -47.1 22.0)"/><ellipse cx="-44.9" cy="10.0" rx="2.8" ry="7.5" transform="rotate(140 -44.9 10.0)"/><ellipse cx="-50.8" cy="11.3" rx="2.8" ry="7.5" transform="rotate(196 -50.8 11.3)"/><ellipse cx="-46.0" cy="0.0" rx="2.8" ry="7.5" transform="rotate(152 -46.0 0.0)"/><ellipse cx="-52.0" cy="0.0" rx="2.8" ry="7.5" transform="rotate(208 -52.0 0.0)"/><ellipse cx="-44.9" cy="-10.0" rx="2.8" ry="7.5" transform="rotate(164 -44.9 -10.0)"/><ellipse cx="-50.8" cy="-11.3" rx="2.8" ry="7.5" transform="rotate(220 -50.8 -11.3)"/><ellipse cx="-41.7" cy="-19.4" rx="2.8" ry="7.5" transform="rotate(177 -41.7 -19.4)"/><ellipse cx="-47.1" cy="-22.0" rx="2.8" ry="7.5" transform="rotate(233 -47.1 -22.0)"/></g></g>
  <text x="0" y="-6" text-anchor="middle" class="seal-v">VERIFIED</text>
  <text x="0" y="10" text-anchor="middle" class="seal-s">CERTIFICATE of</text>
  <text x="0" y="22" text-anchor="middle" class="seal-s">ACHIEVEMENT</text>
</svg>`,
  sign: `<svg class="sign" viewBox="0 0 300 110" aria-label="Signature of Fazle Rabbi">
  <g fill="none" stroke="#10213f" stroke-linecap="round" stroke-linejoin="round">
    <path stroke-width="3.4" d="M46 92 C40 62 50 26 84 15 C104 9 112 24 96 33 C86 39 70 41 58 43"/>
    <path stroke-width="2.2" d="M24 62 C70 50 124 44 176 49"/>
    <path stroke-width="2.6" d="M72 80 C80 60 92 58 94 68 C96 80 84 84 92 72 C100 56 114 58 114 70 C114 82 104 86 116 74 C124 64 134 62 138 70 C141 78 132 80 142 68 C150 58 162 58 168 64"/>
    <path stroke-width="3.2" d="M182 88 C178 54 190 20 216 15 C236 12 238 34 216 43 C208 47 198 47 194 47 C210 49 226 58 223 74 C222 84 232 86 238 76"/>
    <path stroke-width="2.6" d="M238 76 C246 60 256 58 258 68 C259 76 252 82 260 73 C268 62 278 58 281 66 C283 74 276 78 284 70"/>
    <path stroke-width="2.4" d="M284 70 C288 62 292 54 296 46"/>
    <path stroke-width="1.8" d="M14 99 C80 108 190 104 296 80"/>
    <circle cx="266" cy="52" r="1.8" fill="#10213f" stroke="none"/>
  </g>
</svg>`
};
