/* ==========================================================
   BELVORINÉ MIXOLOGY – CONFIGURATION  (edit this file only)
   ========================================================== */
window.CERT_CONFIG = {
  BRAND: "Belvoriné Mixology",
  DIRECTOR_NAME: "Fazle Rabbi",           // printed under the signature
  SITE_HOST: "belvorine.lovable.app",     // shown under the QR code

  /* How the QR code works:
     "embedded" -> the certificate details are packed inside the QR link and shown by verify.html.
                   Works with NO database. Anyone who can build a link could fake one, so use it
                   for demos/offline use only.
     "database" -> the QR points to  <DATABASE_VERIFY_URL>/<certificate id>  and your site looks the
                   certificate up in its database (tamper-proof). See docs/DATABASE_MODE.md.       */
  VERIFY_MODE: "embedded",
  SITE_URL: "",                            // "" = auto (folder this page is served from)
  DATABASE_VERIFY_URL: "https://belvorine.lovable.app/verify",

  /* Programs and levels. "award" is the big line on the certificate. Add/rename freely. */
  PROGRAMS: [
    { id: "waiter", name: "Waiter", levels: [
      { award: "Professional Waiter — Level 1 (Basic)" },
      { award: "Professional Waiter — Level 2 (Intermediate)" },
      { award: "Professional Waiter — Level 3 (Advanced)" } ] },
    { id: "bar-career", name: "Bar Career", levels: [
      { award: "Barback — Level 1" },
      { award: "Bartender — Level 2" },
      { award: "Professional Bartender — Level 3" } ] },
    { id: "bartender", name: "Bartender", levels: [
      { award: "Professional Bartender — Level 1 (Basic)" },
      { award: "Professional Bartender — Level 2 (Intermediate)" },
      { award: "Professional Bartender — Level 3 (Advanced)" } ] },
    { id: "barista", name: "Barista", levels: [
      { award: "Professional Barista — Level 1 (Basic)" },
      { award: "Professional Barista — Level 2 (Intermediate)" },
      { award: "Professional Barista — Level 3 (Advanced)" } ] }
  ]
};
