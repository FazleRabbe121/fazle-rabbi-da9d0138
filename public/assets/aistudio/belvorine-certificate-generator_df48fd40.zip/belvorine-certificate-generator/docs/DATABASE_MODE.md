# Database mode – real system (admin panel + candidates + verification)

## Tables
**programs**: id, name
**levels**: id, program_id, level_number (1-3), award_text (e.g. "Professional Bartender — Level 3")
**candidates / certificates**:
- id, certificate_id (unique, `BLV-XXXXXXXX-YYYY`, created when the candidate is added or when the certificate is issued)
- gmail, passcode_hash, failed_attempts, locked_until
- program_id, level_number (set by admin, candidate cannot change)
- full_name, passport_number, date_of_birth, photo (file storage), claimed_at, issued_at (date)
- status: pending | issued | revoked

## Admin panel (/admin) – owner only (email + password, admin role)
- Manage programs and level names.
- Add candidate: Gmail + program + level → system generates an 8-character passcode, shown once to the owner (stored hashed).
- List: Gmail, program, level, status, certificate ID, issue date.
- Actions: reset passcode, revoke, restore, delete pending.

## Candidate page (/get-certificate)
1. Enter Gmail + passcode (lock 15 minutes after 5 wrong tries).
2. Form: full name, passport number, date of birth, photo. Program and level are fixed.
3. On submit: set claimed_at and issued_at = today; details can no longer be edited.
4. Show the certificate (`Certificate.render`) with the stored data and a Download PDF button.
5. Later visits with the same Gmail + passcode: view/download only.

## Verification (/verify/:certificate_id) – public
Reachable by scanning the QR code or by typing the ID in the homepage box.
Shows: photo, full name, date of birth, passport masked (`••••••123`), program + level, issue date, certificate ID.
Not found → "Certificate not found". Revoked → "This certificate has been revoked".

## Security
- Passport numbers and photos readable only by the admin and the certificate holder (row-level security).
- Public pages expose only what is listed above.
- QR contains only the verify URL, never personal data.
