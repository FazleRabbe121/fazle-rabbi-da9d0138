# Belvoriné Mixology – Certificate Generator

A complete, dependency-free certificate system in plain HTML / CSS / JavaScript.
You change only **the name, the program and the level**; everything else is automatic:

| What | How |
|---|---|
| Certificate | Built by code from a template (frame, stamp, signature, seal, watermarks) – not a picture |
| Candidate name, program, level, issue date | Filled in from the form |
| Certificate ID | Generated automatically and unique, format `BLV-XXXXXXXX-2026` |
| QR code | Generated automatically for every certificate (works offline) |
| PDF | "Download PDF / Print" → choose "Save as PDF" (A4 landscape, colours kept) |

See `examples/` for finished sample certificates.

## Run it
Open `index.html` in a browser, or upload the whole folder to any static host.
1. Type the candidate's name, choose Program and Level, press **Generate**.
2. Press **Download PDF / Print** and save as PDF.

## Customise (only `js/config.js`)
- `DIRECTOR_NAME`, `SITE_HOST`
- `PROGRAMS`: add / rename programs and the big award line for each of the 3 levels
- `VERIFY_MODE`: `"embedded"` (no database) or `"database"` (recommended for real use)

## Folder
```
index.html            generator page (form + live preview + print)
verify.html           page opened when the QR code is scanned (embedded mode)
js/config.js          settings, programs, levels
js/certificate.js     core logic: create(), render(), verifyUrl(), decode()
js/template.js        certificate HTML template, stamp, seal, signature (SVG)
js/qrcode.js          bundled QR generator (MIT, Kazuhiko Arase)
js/app.js             form behaviour
css/certificate.css   certificate design (1123 x 794 px = A4 landscape)
css/app.css           generator page styling
examples/             example certificates (PNG) + sample-data.json
docs/DATABASE_MODE.md full plan for a real system with admin panel and database
AI_INSTRUCTIONS.md    briefing for an AI assistant that will integrate this
```

## Important: embedded vs database mode
In **embedded** mode the QR link carries the certificate details itself, so it works without any server, but anybody who can build such a link could create a fake. Use it for demos.
For real certificates use **database** mode: the QR only carries `/verify/<ID>`, and your website looks the ID up in its own database, so only certificates you really issued can be verified. Read `docs/DATABASE_MODE.md`.
Never put passport numbers in a QR code or public page; show them masked (last 3 characters).
