# Instructions for the AI assistant

You are given a finished, working certificate generator for **Belvoriné Mixology** (domain: https://belvorine.lovable.app).
Your job is to integrate it into the website. **Do not redesign the certificate and do not replace it with an image.**
The certificate MUST stay code-generated.

## What the code does
- `Certificate.create({name, programId, level, issuedAt, id?})` returns a data object and generates a unique ID `BLV-XXXXXXXX-YYYY` (random, no look-alike characters).
- `Certificate.render(data)` returns the full certificate HTML (fixed 1123 x 794 px, A4 landscape) with name, award line, issue date in the stamp, ID, and an automatically generated QR code (SVG).
- `Certificate.verifyUrl(data)` is the link inside the QR code.
- Design lives in `css/certificate.css` + `js/template.js`. Settings and programs live in `js/config.js`.
- Printing to PDF: the browser print dialog (`@page` A4 landscape, `print-color-adjust: exact`).

## Programs and levels (editable)
Waiter L1-3 · Bar Career: L1 Barback, L2 Bartender, L3 Professional Bartender · Bartender L1-3 · Barista L1-3.
The sentence on the certificate reads: "has successfully completed the Belvoriné Mixology Level N <Program> assessment and has been awarded a certificate in <award line>".

## Required product behaviour (see docs/DATABASE_MODE.md for details)
1. Admin panel (/admin, owner only): add a candidate's Gmail, pick program + level, system creates a one-time passcode.
2. Candidate (/get-certificate): Gmail + passcode → form (full name, passport number, date of birth, photo) → certificate is generated automatically (ID + QR) → Download PDF.
3. Verification: scan QR or type the ID on the homepage → /verify/<ID> shows photo, name, date of birth, MASKED passport (last 3 chars), program + level, issue date, ID. Unknown ID → "Certificate not found". Revoked → "This certificate has been revoked".
4. Use `VERIFY_MODE: "database"` in production. The QR must contain only `https://belvorine.lovable.app/verify/<ID>`.

## Rules
- Keep the certificate design exactly as in `examples/*.png` (reference images).
- Port `render()` into your framework (e.g. a React component) by keeping `template.js` markup and `certificate.css` unchanged; only the data tokens change (`__NAME__`, `__TITLE__`, `__SENTENCE__`, `__DATE__`, `__ID__`, `__QR__`, `__DIRECTOR__`, `__HOST__`).
- If a React/TypeScript QR library is available you may use it instead of `js/qrcode.js`; the QR must encode the verify URL.
- Never show a full passport number publicly; store it so only the admin and the holder can read it.
- Generate IDs on the server (or database default) in production and enforce uniqueness.
