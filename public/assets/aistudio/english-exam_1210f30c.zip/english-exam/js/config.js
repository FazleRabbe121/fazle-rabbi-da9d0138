/* Edit this file to configure the exam for your software. */
window.EXAM_CONFIG = {
  brand: 'English Level Exam',
  timeLimitMin: 45,          // total exam time
  showAnswers: true,         // show correct answers to the candidate after submit
  endpoint: '',              // e.g. '/api/english-exam/submit' (POST, multipart/form-data). Leave '' to disable.
  csrfToken: ''              // Laravel: pass document.querySelector('meta[name=csrf-token]').content if embedded in a Blade page
};
