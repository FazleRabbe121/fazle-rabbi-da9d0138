# MASTER BUILD PROMPT — AI INTERVIEW & ENGLISH ASSESSMENT CENTER
Copy this entire prompt into the existing project in Google AI Studio.

## Non-negotiable requirement
Build a new, separate module called **AI Interview & English Assessment Center**. Do not rebuild the application. Do not change, remove, restyle, or break any existing feature, route, database, passcode flow, integration, or settings. Inspect the current project first; reuse the current stack and components. Make changes only for this new module.

## 1. Required participant access and Admin Control Panel
- Keep the existing app passcode system unchanged.
- Add a separate “Interview Access” option below/near the current passcode option.
- Admin-only Control Panel must let the authorized admin add, approve, suspend, and revoke exact Google account email addresses; optionally set expiry and permitted categories; and generate/copy a participant link.
- A participant must sign in with Google. Compare the authenticated provider email against the approved allowlist on the server. Do not trust a typed email alone.
- An approved participant sees ONLY the Interview Portal. They must not access the main app, other routes, CV library, API settings, admin panel, or other participants’ records—even by manually entering a URL or calling an API.
- Enforce access in server/API authorization and database/storage security rules, not merely by hiding navigation.
- Only the authorized administrator can access the control panel and see all participants’ results. Never hard-code admin access based only on a client-side flag.

## 2. Participant experience
After access is approved, show only:
A. Professional Interview
   - Waiter
   - Bartender
   - Barista
   - Maintenance Electrician
   - Plumber
B. English Level Assessment
   - CEFR A1, A2, B1, B2, C1, C2
Each professional role has Level 1 (beginner), Level 2 (intermediate), and Level 3 (advanced). Each session must run for at least five minutes. Use enough questions and follow-ups to support five minutes; do not finish early just because a fixed small question list was exhausted. Target 5–7 minutes for Level 1, 8–10 minutes for Level 2, and 10–15 minutes for Level 3. If the product owner later sets a strict 5-minute cap, make the duration configurable.

## 3. Spoken and written modes
- Default interview mode is SPOKEN. Display a clear notice: “You must answer aloud in English. Tap Start, allow microphone access, listen to each question, and speak your answer. Do not type unless you select Written Practice.”
- Request microphone permission only when needed. Show recording/transcription state and clear errors. Use supported speech-to-text integration; do not pretend browser speech recognition works on every device. Provide Written Practice as a separate mode.
- Ask one question at a time. Allow a repeat-question action. Save progress after each answer. If a provider fails or the page refreshes, resume safely without losing answers.
- Evaluate only evidence actually available. Do not claim to assess pronunciation from text transcription alone. If audio pronunciation analysis is unavailable, say so clearly.

## 4. Question bank and answer evaluation
Use the full question banks in `QUESTION_BANKS_EN.md` as seed content. Questions must be role-specific, progressively harder, and not generic duplicates across professions. Randomize safely from the approved bank; maintain consistent difficulty and avoid repeating questions within one attempt. Use follow-up questions when answers are too short or vague.
- The question bank includes evaluator criteria and expected answer points. These are for the AI evaluator/admin, not automatically shown to candidates before answering.
- Do not show model answers before the candidate answers. After the interview, provide feedback and example answers if configured.
- For electrician/plumber content, preserve the technical topics and evaluator guidance from the supplied source PDF; use current local codes and qualified-person safety requirements for real work. Interview content is not a substitute for training or authorization to perform hazardous work.
- English assessment tests listening (if supported), spoken response, grammar, vocabulary, fluency, coherence, and task completion. Produce an estimated CEFR level, not an official certificate.

## 5. Scorecard and pass/fail
Each professional interview is scored out of 100. Default rubric:
- Role knowledge / practical procedures: 25
- Situational judgement / problem-solving: 25
- English grammar and vocabulary: 20
- Clarity and fluency: 20
- Professionalism, teamwork and safety: 10
Admin can configure rubric per role.
Default pass threshold: 70/100, configurable by admin. For safety-critical electrical/plumbing questions, a critical unsafe answer must be flagged and may result in “Fail — Safety Concern” even if the numeric score passes. Show:
- PASS or FAIL, total score, rubric breakdown, strengths, weaknesses, grammar corrections, recommended practice, and next level.
- Make clear that this is an AI practice assessment, not a legally recognized professional license or official CEFR certificate.
- Do not alter past results if scoring rules later change; store rubric/version with each attempt.

## 6. Admin dashboard and history
Admin must be able to:
- Add/remove approved emails and revoke access.
- See participant name/email, role, level, mode, start/completion time, duration, score, PASS/FAIL, provider used, and status.
- Open each attempt to review questions, transcript/typed answers, rubric scores, feedback, and source/version of question bank.
- Filter by email, role, level, date, score, pass/fail and incomplete attempts.
- Export results to CSV if the current stack supports it safely.
- Preserve full history; never overwrite a prior attempt with a new attempt. Keep attempt IDs unique.
- Participant can see only their own results, if result viewing is enabled. Never expose another user’s data.
- Provide retention/deletion controls for transcripts and recordings. Obtain consent before audio recording and store only what is necessary.

## 7. AI providers and automatic fallback
Reuse the app’s already configured OpenAI/ChatGPT, Grok, and Gemini integrations. Do not ask the user to paste secrets into chat. Keep keys server-side/secrets only.
- OpenAI and Grok are preferred for interview generation/evaluation; use the configured routing strategy to avoid redundant calls. Gemini is fallback when preferred providers are rate-limited, quota-exhausted, timed out, or temporarily unavailable.
- Detect and distinguish 401 invalid credentials, 403 permissions, 429 rate/quota limits, timeouts, and provider 5xx errors. Do not pretend switching providers can fix invalid keys for all providers.
- If one provider fails, switch safely; if OpenAI and Grok are unavailable, use Gemini. Preserve the current question and answers and do not duplicate score writes.
- Admin panel must show provider health, last successful request, last error, fallback events and timestamp. Do not claim exact remaining credits unless provider provides reliable quota data.
- If all providers fail, save progress and show a retry/resume message. Avoid infinite retries and excessive API calls.
- Use one consistent output schema/rubric across providers. For conflicting evaluations, flag for review instead of hiding disagreement.

## 8. Data model and security
Adapt to the existing database; do not duplicate equivalent tables. Minimum logical entities:
- approved_participants: email, provider UID, status, allowed modules/categories, created/expiry/revoked timestamps, created_by
- interview_attempts: attempt ID, participant UID, role/category, level, mode, status, started/completed timestamps, duration, question-bank version, rubric version, provider/fallback log, score, pass/fail
- interview_answers: attempt ID, question ID, answer transcript or written answer, answer timestamp, per-question feedback/scores
- question_bank: role, level, question, follow-ups, expected answer points, rubric, source
- provider_events: provider, event type, timestamp, error class, fallback outcome (never store secrets)
- admin audit events: who changed access/settings and when
Use server-side authorization, least privilege, secure session handling, rate limiting, input validation, private file storage, and access-controlled database rules. Never expose API keys, OAuth tokens, or secrets in client code or logs.

## 9. Implementation plan and acceptance tests
Phase 1: Audit existing code and show the minimal plan. Identify existing login, storage, database, APIs and routes. Do not edit until the plan is clear.
Phase 2: Implement only the isolated Interview Center and necessary security/backend support.
Phase 3: Test using mocked provider failures and test accounts; do not send real emails or real employer applications.
Required tests:
- Approved Google account can enter; unapproved/revoked account cannot.
- Participant cannot reach admin or main app routes/APIs.
- One participant cannot access another participant’s attempt.
- Each role and each level launches the correct questions and lasts at least five minutes.
- Spoken mode requests microphone permission and handles denial gracefully.
- Answers autosave and session resumes after refresh/provider failure.
- Scores, pass/fail, history and exports are persisted correctly.
- OpenAI/Grok failure routes to Gemini appropriately.
- Invalid credentials are shown as configuration errors, not falsely described as quota exhaustion.
- All existing features still work unchanged.
At completion, report changed files, required setup, tests actually run, limitations, and rollback steps. Never claim success without testing. If any feature already exists and works, reuse it instead of rebuilding it.
