# MASTER PROMPT — CareerPilot AI Professional Intelligence Upgrade

You are working on my EXISTING CCD / CareerPilot AI application. It already includes job search, Europe Job Market, Sponsorship, CV Library, application sending, application history, and AI features. Do not rebuild it.

## Mandatory rules
1. Inspect the current codebase, architecture, data storage, integrations, and UI before editing.
2. First provide a concise audit of existing features, implementation gaps, and a minimal change plan. Do not edit code during the audit.
3. Preserve all working features, existing user data, settings, Gemini/Gmail integrations, CV files, and application history.
4. Do not remove or replace working features, rewrite unrelated modules, or redesign the entire app.
5. Never expose or hard-code API keys, OAuth tokens, passwords, or secrets.
6. Never invent vacancies, employers, HR contacts, sponsorship evidence, application results, or email delivery confirmations.
7. Separate verified facts, indirect evidence, inferences, and unknowns. Store source URLs and verification dates where available.
8. Reuse existing infrastructure. Do not add paid services or dependencies without explaining why and getting approval.
9. Do not submit real applications, send follow-ups, or change external account settings without explicit user approval.
10. Never claim code was changed or tested unless it actually was.

## Advanced features to add only if genuinely missing
- Employer Intelligence Profile: official careers pages, vacancy evidence, hiring channels, role history, and sponsorship evidence with sources and confidence labels.
- Explainable Opportunity Prioritization: score role fit, experience, language, location, sponsorship evidence, vacancy freshness, and contact quality; explain the score without claiming it guarantees hiring.
- Vacancy Change Detection: detect new/updated/closed vacancies, deduplicate by stable ID or normalized URL, and preserve applied jobs in history.
- Application Outcome Analytics: analyze actual recorded statuses such as submitted, bounced, reply, interview, rejected, and unknown. Gmail acceptance is not confirmed delivery.
- Contact Verification Queue: prioritize the exact vacancy application method and official HR/recruitment contacts; never guess addresses.
- Safe Application Operations: per-application statuses, idempotent retries, sequential sending when appropriate, and user confirmation before external sends.
- Career Mission Control: show qualified new jobs, items needing review, confirmed send attempts, bounces/failures, follow-ups due, interviews, and unresolved tasks.
- Evidence & Audit Trail: record source, timestamp, entity, outcome, and error without exposing credentials.

## Workflow
Phase 1 — Audit only: map existing modules and identify which features already exist. Report overlaps and gaps. Do not change code.
Phase 2 — Plan: list the smallest necessary changes, affected files, data migrations, risks, and rollback plan. Wait for approval before broad/destructive changes.
Phase 3 — Implement approved missing features only. Reuse existing UI, state management, storage, APIs, and design tokens.
Phase 4 — Test duplicate prevention, source failures, uncertain send outcomes, invalid contacts, bounce handling, data persistence, and regressions. Use mocked/test data, not real employers.

## Acceptance criteria
- No existing feature is removed or silently degraded.
- Existing data and application history remain intact.
- No fake jobs, guessed contacts, unsupported sponsorship claims, or false delivery statuses.
- New functionality is explainable, auditable, and safe.
- Changed files, test results, and limitations are reported.
- If a feature already exists and works, do not recreate it.

Begin with Phase 1 audit. Do not edit files until you have presented the audit and minimal implementation plan.
