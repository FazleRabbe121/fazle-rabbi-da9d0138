# Product Blueprint — Advanced Career Intelligence

## Objective
Make CareerPilot AI an evidence-based career operations system without duplicating existing features.

## A. Employer Intelligence Profile
Consolidate the employer's official careers page, relevant vacancies, published application method, official contact source, documented international hiring/work-permit evidence, last checked date, confidence, and unknowns. Do not infer sponsorship eligibility from brand size or past hiring alone.

Evidence labels: Verified official evidence / Credible indirect evidence / Unverified signal / No evidence found.

## B. Explainable Opportunity Prioritization
Rank opportunities by role/skill fit, experience, language, location, work authorization or sponsorship evidence, vacancy freshness, and contact quality. Explain the factors and missing information. A score is not a probability of hiring.

## C. Vacancy Change Detection
Track stable IDs or normalized official URLs. Distinguish new, updated, closed, already applied, and duplicate listings. Preserve application history if a source listing disappears. A failed fetch is not proof that a vacancy closed.

## D. Application Outcome Analytics
Use actual recorded states: prepared, send attempted, accepted by Gmail, bounce confirmed, employer reply, interview, rejection, unknown. Do not equate Gmail acceptance with delivery or delivery with employer response.

## E. Contact Verification Queue
Prefer the exact application method in the vacancy, then official employer recruitment sources. Store source URL, verification date, type, and confidence. Never guess personal email patterns. Block automatic retries to invalid/bounced contacts until corrected.

## F. Safe Application Operations
Use one record per vacancy/application attempt, idempotent retries, separate recipient statuses, bounded retry logic, and user confirmation before external sends and follow-ups.

## G. Career Mission Control
Show new high-fit jobs, opportunities needing review, verified contacts, pending sends, Gmail acceptance, bounced/failed applications, replies/interviews, follow-ups due, and sources needing refresh. Metrics must derive from real records and show last update time.

## H. Evidence & Audit Trail
Record source/operation, timestamp, entity ID, outcome/status, and error summary. Do not store unnecessary personal data or expose secrets.
