# Data Model & Workflow Notes

Adapt these concepts to the current schema. Do not create duplicate tables when equivalent structures exist.

## Employer
employer_id, canonical_name, official_domain, official_careers_url, source_urls, last_verified_at, evidence_summary, evidence_confidence.

## Vacancy
vacancy_id, employer_id, canonical_url, source_id, title, location, published_at (nullable), first_seen_at, last_seen_at, last_successful_check_at, vacancy_status, content_fingerprint, sponsorship_evidence_status, source_url.

## Contact
contact_id, employer_id, email_or_application_url, contact_type, source_url, verified_at, verification_status (verified/unverified/bounced/rejected/unknown), notes.

## Application
application_id, vacancy_id, employer_id, contact_id (nullable), selected_cv_id, cover_letter_version, application_status, created_at, last_attempt_at, gmail_message_id (nullable), last_error_code/message (nullable), attempt_count, follow_up_status.

## Audit event
event_id, entity_type, entity_id, event_type, timestamp, outcome, source_or_operation, error_summary (nullable).

## Safeguards
- Make retries idempotent.
- Never delete an application because a vacancy disappears.
- A failed source fetch is not proof a vacancy closed.
- Do not count unknown outcomes as successes or failures.
- Keep secrets out of logs.
- Apply migrations only if necessary and provide rollback instructions.
