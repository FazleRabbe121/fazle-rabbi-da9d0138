# CareerPilot AI — Professional Enhancement Pack

এই প্যাকটি আপনার বিদ্যমান CCD / CareerPilot AI অ্যাপের উন্নত ফিচার পরিকল্পনা ও বাস্তবায়ন নির্দেশিকা।

## ব্যবহার
1. ZIP ফাইলটি বর্তমান Google AI Studio প্রজেক্টের সঙ্গে দিন, যদি ফাইল আপলোডের সুবিধা থাকে।
2. `MASTER_IMPLEMENTATION_PROMPT_BN.md` কপি করে AI Studio-তে পেস্ট করুন।
3. প্রথমে বর্তমান কোডের audit ও implementation plan তৈরি করতে বলুন।
4. পরিকল্পনা যাচাই করে তারপর বাস্তবায়ন করতে দিন।
5. পরিবর্তনের আগে বর্তমান প্রজেক্টের ব্যাকআপ রাখুন।

## গুরুত্বপূর্ণ
এই ZIP আপনার অ্যাপের সোর্স কোড নয়; এটি একটি professional enhancement/specification pack। কোনো API key, Gmail password বা গোপন তথ্য ZIP-এ রাখবেন না। বিদ্যমান ফিচার, ডেটা, CV Library, Gmail, Sponsorship, Europe Job Market ও application history অকারণে বদলানো যাবে না।
