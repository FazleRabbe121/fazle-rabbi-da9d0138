# UX & Design System — Professional, Calm, Trustworthy

Use the existing design system; refine only components needed for approved features. Aim for a premium, restrained, professional career-operations interface—not a decorative marketing page.

- White or near-white surfaces, readable typography, strong contrast, consistent spacing.
- Text-first job cards, not decorative stock photos.
- Avoid excessive gradients, animation, blank space, and crowded badges.
- Use semantic status colors but never rely on color alone.
- Keep mobile responsiveness, accessible touch targets, and existing dark/light themes.
- Do not add duplicate navigation if equivalent sections already exist.

Suggested information architecture, only where missing: Mission Control, Europe Job Market, Sponsorship Intelligence, Employer Profiles, CV Library, Applications & Delivery, Analytics, Settings.

Job cards should show title, employer, location, source/last checked date, match explanation, sponsorship evidence, contact verification, application status, and clear actions.

Always show sources, last-checked dates, uncertainty, and useful empty states. Never display fabricated metrics, verification badges, success rates, or live status.
