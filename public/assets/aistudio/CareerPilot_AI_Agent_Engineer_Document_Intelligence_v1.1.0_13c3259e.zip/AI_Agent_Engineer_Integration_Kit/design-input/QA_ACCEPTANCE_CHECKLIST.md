# QA & Acceptance Checklist

## Regression
- [ ] Existing routes and navigation work.
- [ ] CV Library and attachments remain intact.
- [ ] Gemini/Gmail configuration is preserved.
- [ ] Sponsorship and Europe Job Market work.
- [ ] Application history is intact.
- [ ] Theme and responsive layout remain intact.

## Evidence quality
- [ ] Official source URLs are visible.
- [ ] Guessed emails are never labeled verified.
- [ ] Sponsorship claims are evidence-backed and uncertainty is shown.
- [ ] Stale or unavailable data is not presented as current.

## Vacancy discovery
- [ ] Genuine new vacancies appear.
- [ ] Duplicate listings are deduplicated.
- [ ] Updated listings are not falsely marked new.
- [ ] Source outages do not mark vacancies closed.
- [ ] Applied vacancies remain in history.

## Application safety
- [ ] Gmail acceptance is not called confirmed delivery.
- [ ] Bounce maps to the correct application.
- [ ] Permanent invalid-address errors do not retry indefinitely.
- [ ] Temporary errors retry only within limits.
- [ ] Uncertain send outcomes do not cause duplicate sends.
- [ ] No real employer emails are used for tests.
- [ ] User approval is required for real sends/follow-ups.

## Analytics and release
- [ ] Metrics come from persisted records.
- [ ] Unknown outcomes are not counted as success/failure.
- [ ] Empty states and timestamps are accurate.
- [ ] Root causes, changed files, tests, limitations, and rollback path are reported.
