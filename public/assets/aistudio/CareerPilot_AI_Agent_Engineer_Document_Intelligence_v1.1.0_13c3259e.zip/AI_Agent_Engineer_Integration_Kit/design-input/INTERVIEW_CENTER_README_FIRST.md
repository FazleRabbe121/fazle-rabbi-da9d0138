# Interview Center Full Build Pack

Files:
- MASTER_BUILD_PROMPT.md: paste into your existing Google AI Studio project.
- QUESTION_BANKS_EN.md: seed question bank for Waiter, Bartender, Barista, Maintenance Electrician, Plumber, and CEFR A1–C2.

Recommended workflow:
1. Keep a backup of the current app.
2. Upload this pack to the existing project.
3. Paste the master prompt.
4. Require an audit and minimal implementation plan before code changes.
5. Verify participant allowlist, admin-only history, and data isolation before inviting real participants.

This pack is a specification and question bank, not a finished deployable application. The app still needs working authentication, secure database rules, microphone/transcription integration, AI provider setup, and testing. Never put API keys in the question bank or browser code.
