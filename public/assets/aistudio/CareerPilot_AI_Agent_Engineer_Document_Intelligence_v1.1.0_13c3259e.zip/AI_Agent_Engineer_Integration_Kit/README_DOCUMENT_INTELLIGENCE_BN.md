# CareerPilot Document Intelligence Upgrade — v1.1.0

এই আপগ্রেডে CareerPilot AI Agent Engine-এ Advanced Professional Writing ও PDF Generation যোগ করা হয়েছে।

## নতুন ফিচার
- Local/self-hosted Ollama model দিয়ে structured document writing।
- PDFKit-ভিত্তিক PDF export; cover/title page, optional contents, headings, paragraphs, bullets, simple tables, references, page numbers ও footer।
- Structural Quality Control: title/sections, duplicate headings, content length, prose এবং research source presence।
- Authenticated API routes: `POST /api/agent/v1/documents/pdf` এবং `/api/agent/v1/documents/review`।
- Existing host database/storage adapter-এর মাধ্যমে generated PDF save করার interface।
- Bengali/Unicode support-এর জন্য server-side Unicode font path configure করার নির্দেশনা।

## চালু করা
1. ZIP extract করে মূল project-এ additive merge করুন; পুরো project overwrite করবেন না।
2. `npm install` চালান (PDFKit install হবে)।
3. `.env.example` থেকে `DOCUMENT_FONT_PATH` সেট করুন। বাংলা PDF-এর জন্য লাইসেন্স-অনুমোদিত Noto Sans Bengali TTF দিন।
4. Host app-এর authenticated API handler-এ নতুন routes mount করুন।
5. Existing secure storage-এ PDF save করার adapter যুক্ত করুন।
6. `npm run check` ও `npm test` চালান।

## API request example
```json
{
  "instruction": "Create a detailed bartender interview preparation guide",
  "language": "English",
  "type": "interview-prep",
  "audience": "hospitality applicant",
  "tone": "professional",
  "sourceMaterial": "Approved notes go here",
  "requireSources": false,
  "minWords": 900
}
```
Route `application/pdf` response দেয়। UI-তে quality score-কে structural check হিসেবে দেখাবেন; এটি factual accuracy certificate নয়।

## গুরুত্বপূর্ণ সীমা
- এই ZIP আপনার মূল অ্যাপে নিজে থেকে install হয় না; Google AI Studio-কে প্রকৃত source code audit করে integrate করতে হবে।
- বাংলা PDF-এর জন্য Unicode font configure না করলে built-in Helvetica বাংলা অক্ষর দেখাতে পারবে না।
- এই test suite fake renderer দিয়ে service/QC যাচাই করে। PDFKit-এর real deployment smoke test ও Bengali font rendering পরীক্ষা মূল app environment-এ করতে হবে।
- PDF generation-এর জন্য Ollama model-এর reasoning/JSON output যথেষ্ট হতে হবে; model quality ChatGPT/Claude-এর সমান হবে এমন নিশ্চয়তা নেই।
