# Android থেকে Google AI Studio-তে সংযুক্ত করার ধাপ

1. Chrome-এ Google AI Studio খুলুন এবং **Build mode**-এ যান।
2. যদি আপনার CareerPilot/CCD Job Application source GitHub-এ থাকে, `+` → **Import from GitHub** দিয়ে সেই আসল repository import করুন। যদি সঠিক existing app ইতিমধ্যে খোলা থাকে, নতুন blank project খুলবেন না।
3. এই ZIP-টি project-এর prompt-এর সঙ্গে attach/upload করুন।
4. ZIP-এর `google-ai-studio/MASTER_INTEGRATION_PROMPT_BN.md` ফাইল খুলে সম্পূর্ণ Prompt কপি করে AI Studio-তে পাঠান।
5. প্রথমে শুধু read-only audit ও integration plan চাইবেন। Project ভুল হলে বা মূল app source না থাকলে AI Studio-কে থামতে বলুন।
6. Audit সঠিক হলে GitHub branch/backup তৈরি করে additive integration অনুমোদন দিন।
7. Secrets panel-এ Ollama URL, model name এবং scheduler secret সেট করুন। কোনো credential chat বা source code-এ পেস্ট করবেন না।
8. আপনার app-এর actual CV Library, Gmail OAuth, Interview PDFs/access allowlist, database ও scheduler adapter ম্যাপ না হওয়া পর্যন্ত feature-গুলো live করবেন না।
9. পুরোনো feature regression test, নতুন agent test এবং non-production Gmail test পাস হওয়ার পরই deploy বিবেচনা করুন।

## গুরুত্বপূর্ণ

এই ZIP নিজে থেকে আপনার সফটওয়্যারে সংযুক্ত হয় না। Google AI Studio-কে আপনার মূল source code-এ integration করতে হবে। এই build session-এ মূল CareerPilot Job App repository পাওয়া যায়নি; তাই ZIP-টি additive integration module এবং engineering handoff package।
