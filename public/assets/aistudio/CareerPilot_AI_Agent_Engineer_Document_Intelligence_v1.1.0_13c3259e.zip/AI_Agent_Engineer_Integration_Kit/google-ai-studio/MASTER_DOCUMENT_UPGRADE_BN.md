# CareerPilot — Master Document Intelligence Upgrade (Google AI Studio)

আপনার কাজ হলো বিদ্যমান CareerPilot Job Sponsorship / Job Application / Interview সফটওয়্যারে Document Intelligence v1.1.0 নিরাপদে যুক্ত করা। এটি standalone নতুন app বানানোর নির্দেশ নয়।

প্রথমে সম্পূর্ণ repository read-only audit করুন। Existing features, auth, CV Library, Gmail, Interview Center, Admin Gmail allowlist/PIN, database, file storage এবং design system map করুন। তারপর additive integration plan দিন। মূল ফিচার মুছবেন না, নতুন আলাদা CV library বানাবেন না, অজানা schema ধরে নেবেন না।

এই package-এ:
- `src/documents/document-service.mjs`: model-assisted structured writing pipeline
- `src/documents/document-quality.mjs`: deterministic structural QC
- `src/documents/pdf-renderer.mjs`: PDFKit PDF renderer
- `google-ai-studio/DOCUMENT_INTELLIGENCE_UPGRADE_PROMPT_BN.md`: detailed implementation checklist
- `docs/DOCUMENT_INTELLIGENCE.md`: API, model, font, persistence ও test নির্দেশনা

Integration requirements:
1. Add `pdfkit` runtime dependency and update lockfile.
2. Mount authenticated `POST /api/agent/v1/documents/pdf` and `/api/agent/v1/documents/review` routes in existing backend.
3. Use existing host authentication; never trust `userId` from request body.
4. Connect `OllamaChatClient.generateJSON()` to the DocumentIntelligenceService.
5. Save PDF in existing secure user-scoped storage; no public bucket by default.
6. Add responsive Document Studio UI with instruction, language, document type, tone, source material, generate, preview, download, quality report and history.
7. Bengali output requires a licensed Unicode font (configure `DOCUMENT_FONT_PATH`); verify glyph shaping in the actual PDF renderer. Do not claim Bengali is supported until tested.
8. Research docs require traceable source URLs and a verification workflow. A structural QC score is not factual verification.
9. Limit prompt/source length, generation timeout, output size, page count and per-user concurrency.
10. Run syntax checks, all existing tests, new tests, PDFKit smoke tests, Bengali font smoke tests and regression tests for CV/Gmail/jobs/sponsorship/interview/security.

Do not deploy automatically. Return an audit, implementation diff, tests, unverified integrations, environment variables and rollback instructions for review.
