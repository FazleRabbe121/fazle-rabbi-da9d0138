# GOOGLE AI STUDIO — MASTER INTEGRATION PROMPT
## CareerPilot Autonomous AI Agent Engine (add to the EXISTING application)

**How to use:** Open the existing CareerPilot / CCD Job Application software in Google AI Studio Build Mode (or import its real source repository first). Upload/attach this ZIP to that project. Then send the entire instruction below. Do not start a new blank project.

---

You are now acting as the Principal Software Architect, Senior AI Agent Engineer, Staff Full-Stack Engineer, Database Migration Lead, Security Engineer and QA Lead for my EXISTING CareerPilot / CCD Job Application platform.

I am providing an integration package named `AI_Agent_Engineer_Integration_Kit`. It contains the reusable Agent Engine source code, tests, database reference migration, interview question bank and technical documentation.

## NON-NEGOTIABLE MISSION

Integrate this Agent Engine into the currently open, existing Job Application / Sponsorship software. The objective is to give the existing application a self-hosted, multi-agent AI workforce that can research European hospitality sponsorship opportunities, assess evidence, rank vacancies against the existing candidate CV, draft applications, track approved follow-ups, and provide a source-grounded interview and English-practice experience.

This is an **additive integration**. Do not rebuild the product, replace the app, create a parallel CV library, create a duplicate Gmail connector, or remove/change any working feature outside the approved integration scope.

## 0. FIRST VERIFY THAT THIS IS THE CORRECT PROJECT

Before changing any files, verify the currently open codebase is the user's existing Job Application / Sponsorship application. Inspect the project title, repository, package manifest, routes, database and feature map.

- This is NOT the separate `Belvoriné Certificate Studio` certificate website.
- This is NOT any personal life-tracker / addiction / finance / family Android app.
- If this is not the existing CareerPilot/CCD Job Application app, STOP. Do not create a new app. Report which project is open and request the correct source repository/project.
- If the actual Job Application source code is not present, STOP after the audit and explain exactly which source files/repository are needed. Do not guess or fabricate an integration.

## 1. PHASE ZERO — READ-ONLY CODEBASE AUDIT (NO EDITS YET)

Scan the complete current project, not just the visible UI. Inspect every relevant route, component, server action, function, database table/migration, authentication flow, background task and provider integration.

Create `docs/agent-engine-integration-audit.md` in the host project with:

1. Actual framework/runtime and current build/test commands.
2. Current database provider, schema, migrations and user-ID type.
3. Existing authentication, admin roles and user isolation.
4. Existing Profile / candidate information model.
5. Existing single-source CV Library: upload, file storage, text extraction, selected/default CV semantics, CV IDs and permissions.
6. Existing job discovery/search sources, Europe Job Market, Sponsorship Jobs, filters, duplicate prevention and source provenance.
7. Existing application history, status tracking, application email generation and Gmail OAuth/send implementation (including any known send failures).
8. Existing Interview Center, participant access rules, admin Gmail allowlist and optional PIN behavior, uploaded interview PDFs, question content and assessment records.
9. Existing scheduler/cron/background job mechanism.
10. Existing UI framework, theme tokens, navigation and responsive/mobile patterns.
11. Files that must not be changed.
12. Exact integration points and likely conflicts with files in this ZIP.

Do not alter files until the audit and a safe implementation plan are complete. Keep existing user data intact. Do not run destructive migrations.

## 2. PHASE ONE — INTEGRATION PLAN AND BACKUP

After the audit, prepare a file-by-file implementation plan and show:

- Existing component/service to reuse.
- New file to add.
- Existing file to change, why the change is necessary and how it will remain backward-compatible.
- Database additions (only namespaced `agent_*` tables if an equivalent does not already exist).
- API routes to add.
- Required environment variables / secrets.
- Regression tests to run for every existing feature.

Create a Git branch or a recoverable commit before edits. If Git is not configured, create an export/backup of the current source first. Never overwrite original user files without a recoverable copy.

## 3. PHASE TWO — ADD THE AGENT ENGINE WITHOUT REPLACING THE APP

Use the files in this ZIP as the starting implementation. Read all files, especially:

- `src/agents/*`
- `src/llm/ollama-client.mjs`
- `src/jobs/*`
- `src/applications/*`
- `src/approvals/*`
- `src/interviews/*`
- `src/integrations/*`
- `src/http/create-agent-handler.mjs`
- `src/scheduler/daily-run.mjs`
- `src/storage/in-memory-repository.mjs`
- `migrations/001_agent_engine_reference.sql`

Adapt module boundaries to the existing host app's real runtime. Do not blindly copy the reference SQL or create duplicate tables. Keep the business logic modular and strongly typed according to the existing project's conventions.

### 3.1 Model / AI engine

Default runtime must use a self-hosted Ollama endpoint and an open-weight model configured by server-side environment variables:

- `AGENT_MODEL_PROVIDER=ollama`
- `OLLAMA_BASE_URL`
- `OLLAMA_MODEL`
- optional protected-proxy `OLLAMA_BEARER_TOKEN`

Do not add OpenAI, Gemini or Claude API as mandatory runtime dependencies. Do not silently switch to a paid provider when Ollama is unavailable. Return a truthful `MODEL_UNAVAILABLE` status and leave non-AI features usable where possible.

Google AI Studio itself may use its own build-time capabilities to edit the project; that does not mean the deployed app should rely on Gemini API at runtime. Keep model inference server-side and provider-independent.

**Important model-quality constraint:** An open-weight model is not automatically as capable as ChatGPT or Claude. Build a robust orchestration and evaluation layer, but do not claim parity or invent successful benchmark results. Add an admin-visible model name, model version, connectivity, timeout and last-health status.

The Android phone is the owner's control device, not the long-running model host. The backend needs a private, always-on Ollama server endpoint. Never use the phone's `localhost` as the Cloud Run backend's model URL.

### 3.2 Multi-Agent workforce

Integrate the registered agent roles and their capabilities:

1. Job Discovery Agent
2. Sponsorship Evidence Review Agent
3. Candidate Fit / Job Ranking Agent
4. Application Drafting Agent
5. Interview Preparation / Evaluation Agent
6. Main Orchestrator

Only registered tools may execute. The model may plan tasks, but it must not gain arbitrary shell, terminal, filesystem, credential, unrestricted browser or external messaging access.

Keep max step count, request timeout, source count, job count and run duration configurable. Log an explainable execution trace with safe summaries; redact CV text, candidate secrets and OAuth tokens.

### 3.3 Existing Job Discovery and Sponsorship features

Reuse the existing job-search and Europe Job Market modules. Do not replace them with a new list or make the user manage two separate job stores.

- Start with user/admin-configured official Greenhouse and Lever public job boards from this package.
- Use the current host app's configured sources if it already has a source registry.
- Do not imply these two integrations search every European vacancy. Add a documented provider adapter interface for future approved sources.
- Respect source-specific terms, rate limits, pagination and request limits.
- Preserve each vacancy's original URL, employer, location, published date, source ID, first/last seen timestamps and stable deduplication identity.
- Do not delete previously applied/saved jobs just because a new discovery run does not return them.
- Keep failures per source; one failed board must not erase successful results.

Sponsorship labels must be conservative:

- `confirmed`: explicit positive visa/work-permit sponsorship wording on a configured official employer or official vacancy source, with quote and source URL.
- `possible`: indirect or qualified wording, or a positive statement from a non-official/uncorroborated source.
- `not_supported`: explicit statement that sponsorship is not available or prior work authorisation is required.
- `unknown`: no reliable evidence found.

“Non-EU applicants welcome”, a form asking whether sponsorship is required, relocation assistance, or accommodation do NOT alone prove work-permit sponsorship. Do not make an immigration/legal eligibility decision. Show the exact source excerpt, URL, date checked, confidence and reason to the user.

Candidate-fit score is an explainable prioritisation score only, never a hiring probability or guarantee.

### 3.4 Existing CV Library — SINGLE SOURCE OF TRUTH

This requirement is critical:

- Reuse the existing CV Library and its file IDs/storage permissions.
- Do not add a second upload/gallery/library or copy CV files into agent storage.
- All modules (Sponsorship, Search Jobs, Application Draft, Interview preparation and agent workflows) must resolve the selected CV through the existing central CV Library.
- The agent may extract text server-side for matching and drafting, but should store only the CV reference (`cvId`) in its draft record, not a duplicate file.
- Use the currently selected/default CV unless the user intentionally selects another CV.
- Never invent years of experience, employers, qualifications, permits, language levels or work history. List missing facts clearly.

### 3.5 Existing Gmail and Applications — DO NOT CREATE A NEW GMAIL SYSTEM

Inspect the current Gmail integration and repair/reuse it. Do not add a separate Gmail account connection if the app already has OAuth.

- Reuse the user's existing authorized Gmail sender and existing attachment pipeline.
- Create job-specific subject, email body and cover letter drafts using the central CV.
- Store application state and message/provider IDs in the existing application tracking system or a compatible extension.
- Do not claim an email was delivered because the provider accepted it; track acceptance, bounce, delivery evidence (if available), and employer reply separately.
- Default auto-send must remain disabled.
- Default approved-send setting must remain disabled until an administrator explicitly enables it after testing the Gmail connection: `AGENT_ALLOW_APPROVED_EMAIL_SEND=false`.
- When enabled, each external send still requires a separate visible user approval. The approval token/action must be one-time and claimed atomically to prevent double-sends.
- If a send times out and its outcome is uncertain, mark `needs_review`; do not blindly retry.
- Never send bulk applications, messages to guessed addresses, or messages without a verified recipient/source and user approval.

The daily scheduler must discover and rank opportunities only. It must not silently send applications or follow-up emails.

### 3.6 Existing Interview Center — preserve isolation and access control

Extend the existing Interview Center; do not replace its access control or mix interview-only users with the rest of the app.

Preserve exactly:

- Admin-controlled Gmail allowlist.
- Only the approved Google account can access restricted interview-only portal after sign-in.
- Optional admin-assigned PIN behavior: if PIN exists, require Gmail + PIN; if no PIN exists, follow the current approved-email flow.
- Restricted interview-only link does not expose Job Search, CV Library, admin pages or other application areas.
- Existing approved roles and PDFs must remain accessible according to current permissions.

Connect `getInterviewSourceMaterials()` to the current uploaded interview-preparation PDFs / knowledge store. The supplied `question-banks/QUESTION_BANKS_EN.md` is seed content, not a replacement for the uploaded reference PDFs. Use retrieval with source document/page metadata. Do not reveal evaluator-only notes before a candidate answers.

Support at least:

- Waiter — Levels 1–3
- Bartender — Levels 1–3
- Barista — Levels 1–3
- Maintenance Electrician — Levels 1–3
- Plumber — Levels 1–3
- English CEFR A1, A2, B1, B2, C1 and C2

Role interviews should target at least five minutes (higher levels can be longer). The UI must show the session timer and the service must not allow early finish below the configured minimum. Ask one question at a time. Store transcripts and answer-specific evaluations with source references.

Use the supplied rubric as a configurable practice rubric: role knowledge 25, situational judgement 25, grammar/vocabulary 20, clarity/fluency 20, professionalism/teamwork/safety 10; suggested pass 70. Critical unsafe electrical/plumbing answers may override a pass and must be reviewed carefully.

Do not claim this creates an official CEFR certificate, professional electrician/plumber licence or legally recognised qualification. Do not infer pronunciation from a text transcript. If microphone transcription or real audio analysis is unavailable, say so honestly.

### 3.7 Daily automation

- Integrate with the existing durable scheduler if present; otherwise provide a signed daily endpoint for Google Cloud Scheduler.
- Do not use `setInterval` in serverless runtime or depend on the owner's phone staying awake.
- The scheduler runs only for users who explicitly enabled Agent daily operations.
- Each run is recorded, deduplicated and bounded. Provide source success/failure, new/updated count, sponsorship evidence counts, top-fit jobs, and a clear summary.
- Include idempotency and concurrency protection to prevent overlapping runs.
- No autonomous job applications, Gmail sending or account creation from scheduled tasks.

## 4. DATABASE AND MIGRATIONS

Read `migrations/001_agent_engine_reference.sql` as a reference, not as a blindly executable script.

- Inspect the actual schema and authenticated user ID format.
- Reuse equivalent tables where possible; add only missing `agent_*` records.
- Preserve all existing user/application/CV/interview data.
- Add unique indexes/idempotency for vacancies and approval actions.
- Ensure every row is user-scoped and RLS/authorization is checked.
- The in-memory repository is only for local tests; never use it in production.
- Provide rollback steps and a non-production migration test.

## 5. BACKEND ROUTES AND UI

Mount the routes documented in `docs/API_CONTRACT.md` behind existing auth. Never trust `userId` from request body. The daily scheduler route must require a strong server secret, compare safely, and only process opted-in user IDs.

Integrate the optional `src/ui/AgentMissionControl.tsx` as an additive page/tab in existing navigation using the existing typography, design tokens, dark/light theme and responsive layout. Do not change global styling or existing navigation behavior unnecessarily.

Add owner-visible controls for:

- Model endpoint health and configured model
- Agent enable/disable per workflow
- Job source board configuration
- Daily schedule and last run report
- Usage/latency/errors per model and agent
- Cost/compute budget and run limits
- Pending application approvals
- Execution history and audit trail
- Data retention and agent permission settings

Do not show fake counters, fabricated job totals, fake connectivity or static demo success.

## 6. ENVIRONMENT AND SECRETS

Use `.env.example` as a reference. Store production secrets only in the AI Studio/Cloud Run Secrets manager or existing backend secret store.

Required / optional settings:

- `AGENT_MODEL_PROVIDER=ollama`
- `OLLAMA_BASE_URL`
- `OLLAMA_MODEL`
- `OLLAMA_TIMEOUT_MS`
- optional `OLLAMA_BEARER_TOKEN` for protected reverse proxy
- `AGENT_SCHEDULER_SECRET`
- `AGENT_ALLOW_APPROVED_EMAIL_SEND=false` by default
- `AGENT_AUTO_SEND_ENABLED=false` always for this version
- `AGENT_MAX_JOBS_PER_SOURCE`
- `AGENT_MAX_SOURCES_PER_RUN`
- `GREENHOUSE_BOARD_TOKENS_JSON`
- `LEVER_SITES_JSON`

Do not ask me to paste secrets into chat or source files. Tell me the exact secret name to create in the hosting secrets panel. No API key for OpenAI/Gemini/Claude should be necessary for runtime inference.

## 7. TESTING — REQUIRED BEFORE YOU SAY COMPLETE

Run the package's tests and adapt/add tests in the host app. Required checks:

1. Build, lint, TypeScript and existing project tests pass.
2. Existing Home, Job Search, Europe Job Market, Sponsorship, CV Library, Applications, Gmail, User Profile, Admin and Interview Center flows still work.
3. User A cannot access User B's agent jobs, CV, drafts, approvals or interview sessions.
4. Repeated discovery does not create duplicate jobs.
5. Applied/saved jobs are not lost on later discovery runs.
6. Explicit sponsorship evidence is shown with source quote/link; “non-EU welcome” remains `possible`, not `confirmed`.
7. No sponsorship evidence returns `unknown`, not a fabricated result.
8. Local model offline returns a clear unavailable status; no paid provider fallback is invoked.
9. Application draft uses the selected existing CV and does not make up experience or work-permit status.
10. Requesting an email approval does not send anything. Only an authenticated, one-time approval can invoke the already-connected Gmail service.
11. Duplicate approve clicks do not send twice. Uncertain send result is `needs_review`.
12. Interview allowlist/PIN and interview-only isolation still work.
13. Interview question retrieval uses allowed uploaded PDFs and keeps source references; no pronunciation score from text.
14. Minimum interview duration is enforced.
15. Scheduler secret is required; only opted-in users are processed; no scheduled application/email sending.
16. All external provider failures, timeouts and rate limits are handled without corrupting existing data.

Use mocked providers for automated tests. Do not send real job applications or emails as part of testing. Live provider tests require a non-production account and explicit owner approval.

## 8. REQUIRED DELIVERABLES FROM YOU

After integration, produce `docs/agent-engine-integration-report.md` containing:

- Actual host codebase version / commit used.
- Exact files added and changed.
- Database migration changes and rollback steps.
- Existing services reused (Auth, CV Library, Gmail, interviews, scheduler).
- Environment secrets that the owner must configure (names only; never their values).
- Tests executed and exact pass/fail outcomes.
- Features fully working vs partially implemented vs waiting for credentials/server.
- Ollama connectivity status and installed model name (only if tested; otherwise state not tested).
- Source board coverage configured and limitations.
- Deployment steps, costs not included / external service costs, and operational warnings.

Do not report “complete”, “production-ready”, “ChatGPT-level” or “unlimited” unless the evidence actually supports the statement. Never invent a successful test.

## 9. IMPLEMENTATION ORDER

Use these controlled stages:

A. Read-only audit and plan.
B. Backup/branch.
C. Add Agent Engine core and model gateway.
D. Implement production repository adapter and host-app adapters.
E. Add job source adapters, sponsorship evidence and scoring.
F. Reuse the one CV Library and Gmail integration with approval gate.
G. Extend existing Interview Center with source PDF retrieval and access-control preservation.
H. Add scheduler integration and mission-control UI.
I. Run all new and regression tests.
J. Deliver report and wait for owner review before production deployment or enabling email sends.

**First response required:** complete only Phase Zero audit and provide the integration plan. Do not edit source code until the actual existing application has been confirmed and the plan is presented. After I approve the plan, continue with the implementation stages.

## Document Intelligence Upgrade (v1.1.0)

এই package-এর `src/documents/` এবং `docs/DOCUMENT_INTELLIGENCE.md` পড়ে Advanced Document Studio integrate করুন। `google-ai-studio/MASTER_DOCUMENT_UPGRADE_BN.md` হলো বিস্তারিত implementation instruction। PDFKit dependency, authenticated PDF routes, existing secure storage adapter, Unicode Bengali font configuration, structural QC এবং regression testing বাধ্যতামূলক। বিদ্যমান CV Library-কে duplicate করবেন না।
