# Google AI Studio — CareerPilot Document Intelligence Upgrade Prompt (বাংলা)

আপনি একজন Principal Full-Stack Engineer, AI Document Systems Architect এবং Security Engineer হিসেবে কাজ করবেন। এই ZIP-এ `src/documents/`-এ Document Intelligence Service, deterministic quality checks এবং PDFKit renderer যোগ করা হয়েছে। বিদ্যমান CareerPilot application-এর সঙ্গে এটি নিরাপদে integrate করুন।

## বাধ্যতামূলক প্রথম ধাপ: Audit
1. সম্পূর্ণ বর্তমান repository read-only audit করুন।
2. বিদ্যমান authentication, database, file storage, CV Library, Gmail integration, Interview Center, admin allowlist/PIN এবং routing শনাক্ত করুন।
3. বিদ্যমান package manager, Node version, framework ও deployment constraints পরীক্ষা করুন।
4. কোন ফাইল যোগ/পরিবর্তন হবে, কোন database/storage adapter লাগবে এবং regression risk কী—একটি integration plan দিন।
5. অনুমান করে কোনো schema বা route তৈরি করবেন না। মূল app-এর কোনো feature মুছবেন বা প্রতিস্থাপন করবেন না।

## Integration
- `src/documents/document-service.mjs`, `document-quality.mjs`, `pdf-renderer.mjs` এবং `src/index.mjs` export integrate করুন।
- `package.json`-এ `pdfkit` dependency যোগ করুন; lockfile আপডেট করুন।
- Host app-এর existing authenticated user identity ব্যবহার করে `/api/agent/v1/documents/pdf` ও `/api/agent/v1/documents/review` route mount করুন। Existing authorization middleware bypass করবেন না।
- Existing Ollama model client-এর `generateJSON()` method ব্যবহার করুন। JSON schema validation ও bounded prompt/source input বজায় রাখুন।
- PDF Buffer-কে existing secure file storage-এ user-scoped metadata-সহ সংরক্ষণ করুন। CV Library-কে নতুন করে বানাবেন না; generated documents-এর জন্য existing document storage থাকলে সেটিই ব্যবহার করুন।
- UI-তে Document Studio যোগ করুন: instruction, language, type, audience, tone, source material, generate, preview/download, quality report এবং history।
- User-এর upload করা PDF-কে source হিসেবে ব্যবহার করতে হলে existing PDF parser/RAG pipeline দিয়ে text extract/retrieve করুন; সম্পূর্ণ PDF context-এ ঢোকাবেন না।

## Quality / safety
- QC structural completeness যাচাই করে, factual correctness প্রমাণ করে না—UI-তে এই সতর্কতা দেখান।
- Research document-এ traceable sources বাধ্যতামূলক করুন; source যাচাই না হলে “unverified” দেখান।
- Fake citation, fake job sponsorship, fake qualification বা immigration/legal claim তৈরি করবেন না।
- Bengali/Unicode PDF-এর জন্য `DOCUMENT_FONT_PATH`-এ লাইসেন্স-অনুমোদিত Unicode TTF font configure করুন (যেমন Noto Sans Bengali)। Helvetica fallback-এ বাংলা সঠিক রেন্ডার হবে ধরে নেবেন না।
- User documents private রাখুন; অন্য user-এর document URL/ID অনুমান করে access করা যাবে না। Signed download URL বা authenticated streaming ব্যবহার করুন।
- PDF generation size, request timeout, page count ও output byte limit configure করুন।

## Verification
1. `npm install`, `npm run check`, `npm test` চালান।
2. Actual PDFKit integration smoke test করুন; PDF header, pages, metadata ও download validate করুন।
3. Bengali font দিয়ে Bengali sample PDF তৈরি করে glyph rendering পরীক্ষা করুন।
4. English sample, long report, bullet list, table, references, empty output, malformed model JSON, missing font এবং oversized input পরীক্ষা করুন।
5. Existing CV Gallery, Gmail, Sponsorship, Job Search, Interview Center, allowlist/PIN ও auth-এর regression tests চালান।
6. বাস্তব Model/Storage integration credentials ছাড়া pass হয়েছে বলে দাবি করবেন না।
7. Final report-এ changed files, tests, unverified integrations, required environment variables এবং rollback steps দিন।

প্রথমে audit ও plan দিন। Plan অনুমোদিত হলে additive implementation করুন। Production deploy করবেন না; আগে review-এর জন্য diff ও test report দিন।
