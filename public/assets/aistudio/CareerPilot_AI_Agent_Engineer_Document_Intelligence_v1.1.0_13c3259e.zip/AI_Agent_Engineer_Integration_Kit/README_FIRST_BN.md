# CareerPilot Autonomous AI Agent Engine
## Google AI Studio Integration Kit — v1.1.0

এটি আপনার বিদ্যমান Job Sponsorship / Job Application / Interview সফটওয়্যারে যোগ করার জন্য একটি **modular AI Agent Engineering Engine**। এটি নতুন আলাদা job app নয় এবং আপনার বর্তমান CV Library, Gmail, application history, sponsorship pages বা Interview Center-এর বিকল্প নয়।

## আগে গুরুত্বপূর্ণ সীমাবদ্ধতা বুঝুন

আমি আপনার সংরক্ষিত ফাইলগুলো পরীক্ষা করেছি। সেখানে CareerPilot-এর enhancement/specification pack, Interview Center-এর build pack ও question bank পাওয়া গেছে; কিন্তু মূল CareerPilot/Job Application সফটওয়্যারের সম্পূর্ণ source code এই ZIP-এ বা সংরক্ষিত ফাইলগুলোতে পাওয়া যায়নি। তাই এই ZIP-এ Agent Engine-এর reusable code, database reference migration, integration contract, test suite এবং Google AI Studio-র integration prompt আছে। **এটি আপনার মূল অ্যাপের source code নয় এবং নিজে নিজে অ্যাপে ইনস্টল হয়ে যায় না।**

Google AI Studio-তে আপনার আসল Job Application app/project খুলে এই ZIP upload/attach করুন এবং `google-ai-studio/MASTER_INTEGRATION_PROMPT_BN.md`-এর নির্দেশনা দিন। AI Studio-কে আগে বর্তমান codebase পরীক্ষা করতে, তারপর adapter তৈরি করে Agent Engine integrate করতে বলা হয়েছে। মূল অ্যাপের source AI Studio-তে না থাকলে আগে GitHub থেকে সেই project import করুন বা বর্তমান source attach করুন।

## এই ZIP-এ কী আছে

- **Self-hosted model gateway:** Ollama REST API-র সঙ্গে সংযোগ; OpenAI/Gemini/Claude API বাধ্যতামূলক নয়।
- **Multi-agent orchestration:** নিবন্ধিত agent-দের মধ্যে bounded task planning/delegation; arbitrary shell/code tools নেই।
- **Job discovery:** user-configured Greenhouse ও Lever public job boards থেকে vacancy আনা। এটি সমগ্র ইউরোপের সব job site-এর crawler নয়।
- **Sponsorship evidence:** confirmed / possible / not_supported / unknown classification; উদ্ধৃতি, source URL ও কারণ সংরক্ষণ।
- **Candidate fit scoring:** ব্যাখ্যাসহ 0–100 prioritisation score; এটি চাকরি পাওয়ার probability নয়।
- **Application drafting:** মূল CV Library থেকে CV text নিয়ে job-specific email ও cover letter draft; নতুন CV store তৈরি করে না।
- **Approval gate:** Gmail-এ send করার আগে human approval; default-এ sending বন্ধ।
- **Interview practice:** Waiter, Bartender, Barista, Maintenance Electrician, Plumber এবং English CEFR practice; host app-এর uploaded PDFs/knowledge retrieval adapter ব্যবহার করে।
- **Daily operations endpoint:** Cloud Scheduler বা অন্য durable scheduler দিয়ে daily discovery চালানোর route।
- **Document Intelligence Upgrade:** self-hosted model দিয়ে structured professional writing, PDFKit PDF export, cover/title page, optional contents, headings, bullets, simple tables, references, page numbering এবং deterministic quality checks।
- **Mission Control UI reference:** optional React component ও CSS।
- **Security, architecture, API contract, tests এবং integration prompt।**

## দ্রুত ব্যবহার

1. ZIP extract করুন।
2. প্রথমে `google-ai-studio/MASTER_INTEGRATION_PROMPT_BN.md` পড়ুন।
3. Google AI Studio Build Mode-এ আপনার আসল CareerPilot project খুলুন বা GitHub import করুন।
4. এই ZIP project context-এ দিন।
5. AI Studio-কে প্রথমে read-only audit/report দিতে বলুন; এরপর additive integration করাতে বলুন।
6. `docs/HOST_APP_ADAPTER.md` অনুযায়ী existing Auth, CV Library, Gmail, Interview PDFs এবং database service map করুন।
7. Production database-এ `migrations/001_agent_engine_reference.sql` অন্ধভাবে চালাবেন না। AI Studio-কে existing schema দেখে প্রয়োজনমতো adapt করতে বলুন।
8. Ollama-কে backend থেকে reachable private/secured server-এ চালান এবং secrets panel-এ environment variables দিন।
9. tests এবং existing-app regression checks pass না করা পর্যন্ত production deploy করবেন না।

## API ছাড়া AI চালানো

Default model provider হলো Ollama। এতে প্রতি-token OpenAI/Gemini/Claude API bill নেই। কিন্তু Ollama model চালাতে সার্ভার/কম্পিউটিং, RAM/GPU, বিদ্যুৎ বা cloud hosting লাগবে। আপনার Android phone এখানে control panel হবে; ফোনে থাকা `localhost` Ollama endpoint Cloud Run/AI Studio backend থেকে reachable হবে না। `OLLAMA_BASE_URL`-এ backend থেকে নিরাপদে পৌঁছানো যায় এমন server URL দিতে হবে।

Self-hosted open-weight model-এর reasoning, coding, language quality ChatGPT/Claude-এর সমান হবে—এমন নিশ্চয়তা নেই। Engine-এর architecture উন্নত করা যায়; model quality hardware ও model-এর ওপর নির্ভরশীল।

## Production warning

- `InMemoryAgentRepository` শুধু test/demo adapter। Production-এ existing database-এ adapter তৈরি করতে হবে।
- CV, Gmail tokens, passport details বা API keys frontend/localStorage-এ রাখবেন না।
- Gmail send default-এ off (`AGENT_ALLOW_APPROVED_EMAIL_SEND=false`)। Admin enable করলেও user-এর আলাদা approval লাগবে।
- `AGENT_AUTO_SEND_ENABLED` false রাখুন; unrestricted auto-send এই kit-এ implement করা হয়নি।
- Greenhouse/Lever job boards-এর source identifiers admin-কে configure করতে হবে। Global job coverage বা sponsorship guarantee দাবি করা যাবে না।
- Interview evaluation হলো practice feedback; official CEFR test বা professional trade licence নয়। Transcript থেকে pronunciation score করা হয় না।
- Daily execution চালাতে Cloud Scheduler-এর মতো durable scheduler প্রয়োজন; server process-এর `setInterval`-এর ওপর নির্ভর করবেন না।

## Test status

`npm install` দিয়ে PDFKit dependency install করুন। `npm test` দিয়ে unit/integration-style tests চালান। এই ZIP তৈরির সময় Node.js 22-এ 28টি test pass এবং syntax check pass করা হয়েছে। PDFKit real rendering ও Bengali font rendering deployed environment-এ আলাদাভাবে smoke-test করতে হবে। এগুলো Agent Engine-এর local tests; আপনার live Gmail, Google AI Studio project, database, Ollama server বা live job-board credentials-এর end-to-end test নয়।
